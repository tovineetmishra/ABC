#ESXi-ProfilCompliance
#Check ESXi Host Profil and if not compliant, apply and reboot bost.
#Subtask sent by VMwareDailyMaintenance.ps1

#- Command Line : C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe
#- Argument Line : -command "E:\PS-Scripts\PS-VMWareDailyMaintenance\ESXi-ProfilCompliance.ps1"
#- Start in : E:\PS-Scripts\PS-VMWareDailyMaintenance\
param(
	[string[]]$WorkingFolder = $null,
    [string[]]$vCenter = "eu001vc0011.tp.tpnet.intra",
	[string[]]$ClusterName = $null,
	[string[]]$HostName = $null,
	[bool]$CheckOnly = $true,
	[bool]$Debug = $false
)
[threading.thread]::CurrentThread.CurrentCulture = 'fr-FR'
if ($WorkingFolder -ne $null) { Set-Location -Path $WorkingFolder }

#***********************************************************************
#**************** D�claration des variables ****************************
#***********************************************************************
$LogFileName 					= "$(get-location)\workingfile\ESXi-ApplyProfil-$($vCenter)-$($HostName)$($ClusterName)-$(get-date -format yyyyMMdd-hhmmss).log"
$ArchivePath 					= "$(get-location)\history\$(get-date -format yyyyMMdd)\"
$ExportCsvFileName 				= "$(get-location)\workingfile\ESXi-ApplyProfil-Report-$($vCenter)$($HostName)$($ClusterName).csv"

$ReportingEmailStart 			= "<b>Hi,<br>The list of the following ESXi are not compliant with host profile.</b></br>`n`n"
$ReportingSubject				= "[EDC-VmwareCheck] Host profile on $($vCenter)"
$ScriptErrorMailStart			= "<b>Hi,<br> Host profile check:</b><br/><br/>`n`n"
$ScriptErrorSubject 			= "[EDC-VmwareCheck][EDC-Script-Failed] Host profile on $($vCenter)"

$ApplyList = @() # array for export

#*******************************************************
#**************** FUNCTIONS ****************************
#*******************************************************
. "..\PS-CommonLibrary\CommonFunction.ps1"
. "..\PS-CommonLibrary\OrionLink.ps1"

#*********************************************************
#************* MAIN **************************************
#*********************************************************
Add-Content "$([System.dateTime]::Now) - Starting ESXi-ProfilCompliance" -path $LogFileName
$CredvCenter = new-object -typename System.Management.Automation.PSCredential -argumentlist $RemoteServiceName, $CredPassSvcs

If (-Not (Get-PSSnapin VMware.VimAutomation.Core -WarningAction SilentlyContinue -ErrorAction SilentlyContinue) ) {
	Add-PSSnapin VMware.VimAutomation.Core -ErrorAction SilentlyContinue
}
if ((Test-Path -path $ArchivePath) -ne $True) {
	New-Item $ArchivePath -type Directory | out-null
}

#Connect to vCenter
try {
	Connect-VIServer $vCenter -Credential $CredvCenter | out-null
	Add-Content "$([System.dateTime]::Now) - INFO - Connected to vcenter $($vCenter)" -path $LogFileName
}
catch {
	Add-Content "$([System.dateTime]::Now) - ERROR - Connexion to vCenter $($vCenter)" -path $LogFileName
	$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
	Add-Content $MsgError -path $LogFileName
	$ScriptErrorList.Add("Connexion to vCenter $($vCenter)", $MsgError)
}
#Orion connection
try {
	Add-Content "$([System.dateTime]::Now) - INFO - Connect to Orion" -path $LogFileName
	$CredentialOrion = new-object -typename System.Management.Automation.PSCredential -argumentlist $CredentialOrionNameSvcs, $CredentialOrionPassSvcs
	$Swis = Connect-Swis -host $swisTarget -Credential $CredentialOrion
}
catch {
	Add-Content "$([System.dateTime]::Now) - ERROR - Orion connection" -path $LogFileName
	$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
	Add-Content $MsgError -path $LogFileName
	$ScriptErrorList.Add("Orion connection", $MsgError)
}

#Open ESXi to check
try {
	if ($ClusterName -ne $null) {
		Add-Content "$([System.dateTime]::Now) - INFO - Get-VMHost for $($ClusterName)" -path $LogFileName
		$HostsList = Get-VMHost -Location $ClusterName | Sort Name
	}
	elseif ($HostName -ne $null) {
		Add-Content "$([System.dateTime]::Now) - INFO - Get-VMHost for $($HostName)" -path $LogFileName
		$HostsList = Get-VMHost $HostName
	}
	else {
		Add-Content "$([System.dateTime]::Now) - INFO - Get-VMHost for all ESXi with DRS" -path $LogFileName
		$HostsList = (Get-Cluster | Where { ($_.DrsEnabled -eq $True) }) | Get-VMHost | Sort Name
	}
	Add-Content "$([System.dateTime]::Now) - INFO - $($HostsList.Count) hosts to check" -path $LogFileName
}
catch {
	Add-Content "$([System.dateTime]::Now) - ERROR - Orion connection" -path $LogFileName
	$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
	Add-Content $MsgError -path $LogFileName
	$ScriptErrorList.Add("Get-VMHost", $MsgError)
}

$BlFound = $false
$Cpt = 1
foreach ($OneHost in $HostsList) {
	Add-Content "$([System.dateTime]::Now) - INFO - Check $($OneHost.Name) ($($Cpt) / $($HostsList.Count))" -path $LogFileName
	$BlFound = $True
	try {
		$NeedApplication = Test-VMHostProfileCompliance -VMHost $OneHost
	}
	catch {
		Add-Content "$([System.dateTime]::Now) - ERROR - Test-VMHostProfileCompliance for $($OneHost.Name)" -path $LogFileName
		$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
		Add-Content $MsgError -path $LogFileName
		$ScriptErrorList.Add("$($OneHost.Name)-Test-VMHostProfileCompliance", $MsgError)
	}
	
	if ($NeedApplication -eq $null) {
		Add-Content "$([System.dateTime]::Now) - INFO - $($OneHost.Name) is compliant" -path $LogFileName
	}
	else {
		Add-Content "$([System.dateTime]::Now) - INFO - $($OneHost.Name) is not compliant" -path $LogFileName
		if ($CheckOnly) {
			Add-Content "$([System.dateTime]::Now) - INFO - Check only - Nothing to do" -path $LogFileName
			$output = "" | Select-Object VMHost, ConnectionState, Action
			$output.VMHost = $OneHost.Name
			$output.ConnectionState = "Not compliant"
			$output.Action = "Check only"
			$ApplyList += $output
		}
		else {
			try {
				$ShortHostName = $OneHost.Name.split(".")[0]
				Add-Content "$([System.dateTime]::Now) - INFO - UnmanageNode $($ShortHostName) for 45 minutes" -path $LogFileName
				Set-UnmanageNode -NodeName $ShortHostName -Minute 45 -SwisConnection $Swis | out-null

				Add-Content "$([System.dateTime]::Now) - INFO - Current State $($OneHost.ConnectionState)" -path $LogFileName
				($OneHost | Get-VM | Get-View | Where {$_.Runtime.ToolsInstallerMounted}) | % { Dismount-Tools -VM $_.Name }
				$OneHost | Get-VM | Get-CDDrive | Where { $_.IsoPath -ne $null } | Set-CDDrive -NoMedia -Confirm:$false
				start-sleep -s 15
				
				#Put in maintenance
				Add-Content "$([System.dateTime]::Now) - INFO - $($OneHost.Name) Put in maintenance" -path $LogFileName
				$CptTimeOut = 0
				$task = Set-VMHost -VMHost $OneHost -State "Maintenance" -Evacuate -RunAsync
				$BlContinue = $true
				while ($task.State -eq "Running") {
					start-sleep -s 30
					$CptTimeOut += 1
					if ($CptTimeOut -gt 20) {
						Add-Content "$([System.dateTime]::Now) - ERROR - Timeout on maintenance mode" -path $LogFileName
						$BlContinue = $false
						$AllRunningMaintenancTasks = Get-Task -Status "Running" | Where { $_.Name -eq "EnterMaintenanceMode_Task" }
						$AllRunningMaintenancTasks | Stop-Task -Confirm:$false
					}
				}
				if ($BlContinue) {
					Add-Content "$([System.dateTime]::Now) - INFO - Now in maintenance mode" -path $LogFileName
					$HostProfile = Get-VMHostProfile -Entity $OneHost.Name
					Add-Content "$([System.dateTime]::Now) - INFO - Apply $($HostProfile.VMHostProfile)" -path $LogFileName
					Apply-VMHostProfile -Entity $OneHost.Name -Profile $HostProfile -Confirm:$false

					#Reboot host
					Write-Host ""
					Add-Content "$([System.dateTime]::Now) - INFO - Rebooting" -path $LogFileName
					Restart-VMHost $OneHost.Name -confirm:$false | Out-Null
					# Wait for Server to show as down
					do {
						start-sleep -s 15
						$ServerState = (get-vmhost $OneHost.Name).ConnectionState
					}
					while ($ServerState -ne "NotResponding")
					Add-Content "$([System.dateTime]::Now) - INFO - $($OneHost.Name) is Down" -path $LogFileName
					# Wait for server to reboot
					do {
						start-sleep -s 30
						$ServerState = (get-vmhost $OneHost.Name).ConnectionState
						Write-Host "Waiting for Reboot ..."    }
					while ($ServerState -ne "Maintenance")
					Add-Content "$([System.dateTime]::Now) - INFO - $($OneHost.Name) is back up" -path $LogFileName

					$NeedApplication = Test-VMHostProfileCompliance -VMHost $OneHost.Name
					if ($NeedApplication -ne $null) {
						Add-Content "$([System.dateTime]::Now) - INFO - second pass if needed" -path $LogFileName
						Apply-VMHostProfile -Entity $OneHost.Name -Profile $HostProfile -Confirm:$false
						start-sleep -s 15
					}
					
					# Exit maintenance mode
					Add-Content "$([System.dateTime]::Now) - INFO - Exiting Maintenance mode" -path $LogFileName
					Set-VMhost $OneHost.Name -State Connected | Out-Null
					Add-Content "$([System.dateTime]::Now) - INFO - Orion Manage Node" -path $LogFileName
					Set-RemanageNode -NodeName $ShortHostName -SwisConnection $Swis
					Add-Content "$([System.dateTime]::Now) - INFO - Maintenance Complete" -path $LogFileName
					start-sleep -s 60
					$output = "" | Select-Object VMHost, ConnectionState, Action
					$output.VMHost = $OneHost.Name
					$output.ConnectionState = $OneHost.ConnectionState
					$output.Action = "Apply and reboot"
					$ApplyList += $output
					$BlFound = $true
				}
				else {
					$output = "" | Select-Object VMHost, ConnectionState, Action
					$output.VMHost = $OneHost.Name
					$output.ConnectionState = $OneHost.ConnectionState
					$output.Action = "Time out on Maintenance mode task"
					$ApplyList += $output
					$BlFound = $true
					start-sleep -s 60
				}
				if (($cpt -gt 1) -and $Debug -and $BlFound) { 
					Add-Content "$([System.dateTime]::Now) - INFO - Debug break after first apply." -path $LogFileName
					break
				}				
			}
			catch {
				Add-Content "$([System.dateTime]::Now) - ERROR - Apply Host Profile" -path $LogFileName
				$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
				Add-Content $MsgError -path $LogFileName
				$ScriptErrorList.Add("$($OneHost.Name)-Apply", $MsgError)
				break
			}
		}
	}
	$Cpt += 1
}

if ($ApplyList.count -gt 0) {
	Add-Content "$([System.dateTime]::Now) - INFO - Exporting csv file." -path $LogFileName
	$ApplyList | Export-Csv -path $ExportCsvFileName -Delimiter ";" -Force -NoTypeInformation
}
else {
	Add-Content "$([System.dateTime]::Now) - INFO - all ESXi profil ok" -path $LogFileName
}

if ($ScriptErrorList.count -gt 0) {
	$MsgError = [string]($ScriptErrorList.GetEnumerator() | ConvertTo-HTML -Fragment)
	Send-SMTPmail -to $EmailScriptError -htmlBody $MsgError -Subject $ScriptErrorSubject -Start "$($MailStyle)$($ScriptErrorMailStart)" -FilesAttachment $LogFileName
}

Add-Content "$([System.dateTime]::Now) - INFO - Reporting done" -path $LogFileName
Move-Item $LogFileName -destination "$ArchivePath"
Disconnect-VIServer * -Confirm:$false
