param(
	[string[]]$WorkingFolder = $null,
    [Parameter(Mandatory=$true)] [string[]]$vCenter,
	[Parameter(Mandatory=$true)] [string[]]$Datastores,
	[Parameter(Mandatory=$true)] [string]$DsType,
    [Parameter(Mandatory=$true)] [bool]$TestMode,
    [string[]]$ExcludedDatastores
)
[threading.thread]::CurrentThread.CurrentCulture = 'fr-FR'
if ($WorkingFolder -ne $null) { Set-Location -Path "$($WorkingFolder)" }

#**********************************************************************
#**************** CONSTANTS and VARIABLES  ****************************
#**********************************************************************
$LogFileName 					= "$(get-location)\workingfile\DS-Reclaim-$($vCenter)-$(get-date -format yyyyMMdd-hhmmss).log"
$ExportCsvFileName 				= "$(get-location)\workingfile\DS-Reclaim-report-$($vCenter).csv"
$ArchivePath 					= "$(get-location)\history\$(get-date -format yyyyMMdd)\"

$ScriptErrorMailStart			= "<b>Hi,<br> DataStore Reclaim:</b><br/><br/>`n`n"
$ScriptErrorSubject 			= "[EDC-VmwareCheck][EDC-Script-Failed] DataStore Reclaim on $($vCenter)"

#*******************************************************
#**************** FUNCTIONS ****************************
#*******************************************************
. "..\PS-CommonLibrary\CommonFunction.ps1"

$EmailScriptError = "xprieur@external.technipenergies.com"

#*********************************************************
#************* MAIN **************************************
#*********************************************************
Add-Content "$([System.dateTime]::Now) - Starting DS-Reclaim - $($vCenter) [Datastores=$($Datastores), DsType=$($DsType), TestMode=$($TestMode), ExcludedDatastores=$($ExcludedDatastores)]" -path $LogFileName
try {
	$CredvCenter = New-Object System.Management.Automation.PSCredential ($RemoteServiceName, $CredPassSvcs)
}
catch {
	Add-Content "$([System.dateTime]::Now) - ERROR - PSCredential" -path $LogFileName
	$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
	Add-Content $MsgError -path $LogFileName
	$ScriptErrorList.Add("PSCredential", $MsgError)
}
if (-Not (Get-PSSnapin VMware.VimAutomation.Core -WarningAction SilentlyContinue -ErrorAction SilentlyContinue) ) {
	Add-Content "$([System.dateTime]::Now) - INFO - Chargement PowerCLI" -path $LogFileName
	Add-PSSnapin VMware.VimAutomation.Core -ErrorAction SilentlyContinue
}	

# Disabling timeout
Set-PowerCLIConfiguration -WebOperationTimeoutSeconds -1 -Scope Session -Confirm:$False | Out-Null 

try {
	Add-Content "$([System.dateTime]::Now) - INFO - Connect to vCenter : $($vCenter)" -path $LogFileName
	$Connection = Connect-VIServer $vCenter -Credential $CredvCenter
}
catch {
	Add-Content "$([System.dateTime]::Now) - ERROR - vCenter connect error with $($vCenter)" -path $LogFileName
	$MsgError = "Line number : $($_.InvocationInfo.ScriptLineNumber)<br>Position : $($_.InvocationInfo.PositionMessage)<br>$($_.Exception)"
	Add-Content $MsgError -path $LogFileName
	$ScriptErrorList.Add("Connect error $($vCenter)", $MsgError)
	continue
}

# Looping throught all the datestores with Name XTRM and type VMFS. I am assuming that you want to loop throught datastores that names contains XTRM (so like grep from bash code below), so you should use asterixes: *XTRM*
foreach ($Datastore in $Datastores) {
	try {
		Add-Content "$([System.dateTime]::Now) - INFO - Treating datastore: $($Datastore)" -path $LogFileName
		$FilteredDatastores = (Get-Datastore -Name $Datastore -ErrorAction Stop | where { $_.Type -eq $DsType })
		Add-Content "$([System.dateTime]::Now) - INFO - List of datastores:" -path $LogFileName
		$FilteredDatastores | %{ Add-Content "$([System.dateTime]::Now) - INFO - $($_.Name) - $($_.FreeSpaceGB) - $($_.CapacityGB)" -path $LogFileName } 
	}
	catch {
		Add-Content "$([System.dateTime]::Now) - ERROR - Error during collecting datastores $($Datastore)" -path $LogFileName
		$MsgError = "Line number : $($_.InvocationInfo.ScriptLineNumber)Position : $($_.InvocationInfo.PositionMessage) : $($_.Exception)"
		Add-Content $MsgError -path $LogFileName
		$ScriptErrorList.Add("Error during collecting datastores $($Datastore)", $MsgError)
		continue
	}

	if ($FilteredDatastores) {
		foreach ($ds in $FilteredDatastores) {
			$dsv = $ds | Get-View
			if ($dsv.Summary.accessible -and $dsv.Capability.PerFileThinProvisioningSupported) {

				# This will get one random host from the list of hosts to which Datastore is connected
				Add-Content "$([System.dateTime]::Now) - INFO - Choosing ESX connected to datastore" -path $LogFileName
				$esx = Get-VMHost -Datastore $ds | Get-Random -Count 1
				Add-Content "$([System.dateTime]::Now) - INFO - Choose ESX: $($esx.name)" -path $LogFileName
		
				# Below will allow to run esxcli commands on the selected host
				Add-Content "$([System.dateTime]::Now) - INFO - Connecting to ESX using esxcli: $($esx.name)" -path $LogFileName
				$esxcli = Get-EsxCli -VMHost $esx
				Add-Content "$([System.dateTime]::Now) - INFO - Connected to ESX using esxcli: $($esx.name)" -path $LogFileName
		
				# Below is equivalent to command: esxcli storage vmfs unmap --volume-label $ds.Name
				# The firs null in the bracket is for UNMAPBlockCount (probably default is 200)
				if ($TestMode) {
					if (!($ExcludedDatastores -contains $ds.Name)) {
						Add-Content "$([System.dateTime]::Now) - INFO - Testing mode: Reclaiming on Datastore: $($ds.Name)" -path $LogFileName
					} else {
						Add-Content "$([System.dateTime]::Now) - INFO - Testing mode: Datastore excluded - no reclaiming on: $($ds.Name)" -path $LogFileName
					}
				} else {
					if (!($ExcludedDatastores -contains $ds.Name)) {
						Add-Content "$([System.dateTime]::Now) - INFO - Reclaiming on Datastore: $($ds.Name)" -path $LogFileName
						try {
							$UnmapReturn = $esxcli.storage.vmfs.unmap($null, $ds.Name, $null)
							Add-Content "$([System.dateTime]::Now) - INFO - Reclaiming result: $($UnmapReturn)" -path $LogFileName
						}
						catch [VMware.VimAutomation.Sdk.Types.V1.ErrorHandling.VimException.ViError]{
							Add-Content "$([System.dateTime]::Now) - Error during reclaiming datastores $($ds.Name)" -path $LogFileName
							$MsgError = "Line number : $($_.InvocationInfo.ScriptLineNumber)Position : $($_.InvocationInfo.PositionMessage) : $($_.Exception)"
							Add-Content $MsgError -path $LogFileName
							$ScriptErrorList.Add("Error during reclaiming datastores $($ds.Name)", $MsgError)
						}
					} else {
						Add-Content "$([System.dateTime]::Now) - INFO - Datastore excluded - no reclaiming on: $($ds.Name)" -path $LogFileName
					}
				}
				
			} else {
				 Add-Content "$([System.dateTime]::Now) - ERROR - DS: $($ds.Name), dsv.Summary.accessible: $($dsv.Summary.accessible), dsv.Capability.PerFileThinProvisioningSupported: $($dsv.Capability.PerFileThinProvisioningSupported)" -path $LogFileName
			}
		}
		try {
			$FilteredDatastores = (Get-Datastore -Name $Datastore -ErrorAction Stop | where{ $_.Type -eq $DsType })
			Add-Content "$([System.dateTime]::Now) - INFO - List of datastores after reclaim:" -path $LogFileName
			$FilteredDatastores | %{ Add-Content "$([System.dateTime]::Now) - INFO - $($_.Name) - $($_.FreeSpaceGB) - $($_.CapacityGB)" -path $LogFileName } 
		}
		catch {
			Add-Content "$([System.dateTime]::Now) - Error during collecting datastores $($Datastore)" -path $LogFileName
			$MsgError = "Line number : $($_.InvocationInfo.ScriptLineNumber)Position : $($_.InvocationInfo.PositionMessage) : $($_.Exception)"
			Add-Content $MsgError -path $LogFileName
			$ScriptErrorList.Add("Error during reclaiming datastores $($ds.Name) - After reclaim", $MsgError)
			continue
		}
		
	} else {
		Add-Content "$([System.dateTime]::Now) - No datastore found using pattern: $($Datastores)" -path $LogFileName
	}
}


if ($ScriptErrorList.count -gt 0) {
	$MsgError = [string]($ScriptErrorList.GetEnumerator() | ConvertTo-HTML -Fragment)
	Send-SMTPmail -to $EmailScriptError -htmlBody $MsgError -Subject $ScriptErrorSubject -Start "$($MailStyle)$($ScriptErrorMailStart)" -FilesAttachment $LogFileName
}

Add-Content "$([System.dateTime]::Now) - INFO - Execution done" -path $LogFileName
Move-Item $LogFileName -destination "$ArchivePath"
Disconnect-VIServer * -Confirm:$false