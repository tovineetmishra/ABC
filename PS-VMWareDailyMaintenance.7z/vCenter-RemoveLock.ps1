#vCenter-RemoveLock
#Remove item in Oracle DB table
#Subtask sent by VMwareDailyMaintenance.ps1

#- Command Line : C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe
#- Argument Line : -command "E:\PS-Scripts\PS-VMWareDailyMaintenance\vCenter-RemoveLock.ps1"
#- Start in : E:\PS-Scripts\PS-VMWareDailyMaintenance\
param(
	[string[]]$WorkingFolder = $null,
    [string[]]$vCenter = "eu001vc0011.tp.tpnet.intra",
	[bool]$Debug = $false
)
[threading.thread]::CurrentThread.CurrentCulture = 'fr-FR'
if ($WorkingFolder -ne $null) {
	set-location -Path "$($WorkingFolder)"
}

#***********************************************************************
#**************** D�claration des variables ****************************
#***********************************************************************
$ExportFileName = "$(get-location)\workingfile\vCenter-RemoveLock-List.txt"
$SQLResult = "$(get-location)\workingfile\vCenter-RemoveLock.txt"
$CsvFileName = "$(get-location)\workingfile\vCenter-RemoveLock-List.csv"
$LogFileName = "$(get-location)\workingfile\vCenter-RemoveLock-$(get-date -format HH-mm-ss).log"
$ArchivePath = "$(get-location)\history\$(get-date -format yyyyMMdd)\"

$SubjectError = "-- Error on Remove vCenter Locks  --"
$MailStartError = "<b>Hi,<br> Error in script vCenter-RemoveLock<br/><br/>`n`n"
$Subject = "-- Remove vCenter Locks  --"
$EmailDataError = "edc-system-l3@technipenergies.com"
$MailStart = "<b>Hi,<br>VM locks by NetBackup."

if (!$ExportOnly) { $MailStart += "<font color=red>Removing is plan.</font>"}

#*******************************************************
#**************** FUNCTIONS ****************************
#*******************************************************
. "..\PS-CommonLibrary\CommonFunction.ps1"
. "..\PS-CommonLibrary\OrionLink.ps1"
$EmailDataError = "xprieur@external.technipenergies.com"

#*********************************************************
#************* MAIN **************************************
#*********************************************************
Add-Content "$([System.dateTime]::Now) - Starting vCenter-RemoveLock - $($vCenter)" -path $LogFileName
$RemoteCreds = New-Object System.Management.Automation.PSCredential ($RemoteServiceName, $CredPassSvcs)

if ((Test-Path -path $ArchivePath) -ne $true) {
	New-Item $ArchivePath -type Directory | out-null
}
$blFound = $false
$blRemoveLock = $false

#Connect to Oracle DB and return all lock
try {
	$CommandLine = 'VCENTER55/vCenter55$0914@vCenterDB.world @"includ\vCenter-RemoveLock-List"'
	Add-Content "$([System.dateTime]::Now) - Starting vCenter-RemoveLock-List.sql" -path $LogFileName
	$p = Start-Process -FilePath "sqlplus.exe" -ArgumentList "$($CommandLine)" -Wait -PassThru
	if (($p.ExitCode -eq 0) -and ($p.HasExited)) {
		Add-Content "$([System.dateTime]::Now) - vCenter-RemoveLock-List.sql completed" -path $LogFileName
		$blFound = $true
	}
	else {
		Add-Content "$([System.dateTime]::Now) - vCenter-RemoveLock-List.sql failed" -path $LogFileName
		$ScriptErrorList.Add("Read Oracle DB", $p.ExitCode)
	}
}
catch {
	Add-Content "$([System.dateTime]::Now) - ERROR - Start-Process" -path $LogFileName
	$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
	Add-Content $MsgError -path $LogFileName
	$ScriptErrorList.Add("Start-Process error", $MsgError)
	
}

#Check lock in file
try {
	if ($blFound) {
		Add-Content "$([System.dateTime]::Now) - INFO - Check if lock exits in file $($ExportFileName)" -path $LogFileName
		$pat = '(.{28}) (.{8}) (.{35}) (.{45})'
		$rep = '$1,$2,$3,$4'
		$Locks  = (gc $ExportFileName | where {$_ -ne ""} ) -replace $pat, $rep > $CsvFileName
		$Locks = Import-csv -Path $CsvFileName -header ("VM","ID","METHOD_NAME","REASON") | where {$_ -ne ""} 
		if ($Locks.Count -gt 0) {
			$ListHTML = [string]($Locks | ConvertTo-HTML -Fragment)		
			send-SMTPmail -to $EmailDataError -htmlBody $ListHTML -Subject $Subject -Start "$($MailStyle)$($MailStart)"
			$blRemoveLock = $true
			Add-Content "$([System.dateTime]::Now) - INFO - VM lock, so removing/restart vCenter" -path $LogFileName
		}
		else {
			Add-Content "$([System.dateTime]::Now) - INFO - No VM lock" -path $LogFileName
		}
		Move-Item $CsvFileName -destination ([String]$ArchivePath + [String](get-date -format hhmm) + "-" + [String](([io.fileinfo]$CsvFileName)).Name)
		Move-Item $ExportFileName -destination ([String]$ArchivePath + [String](get-date -format hhmm) + "-" + [String](([io.fileinfo]$ExportFileName)).Name)
	}
}
catch {
	Add-Content "$([System.dateTime]::Now) - ERROR - Check lock in file" -path $LogFileName
	$MsgError = "Line number : $($_.InvocationInfo.ScriptLineNumber)<br>Position : $($_.InvocationInfo.PositionMessage)<br>$($_.Exception)"
	Add-Content $MsgError -path $LogFileName
	$ScriptErrorList.Add("Check lock in file", $MsgError)
}

#Connect to Oracle DB and delete lock
try {
	if ($blRemoveLock -and !$Debug) {
		Add-Content "$([System.dateTime]::Now) - INFO - Removing lock and restart vCenter services" -path $LogFileName
		
		#Unmage in Orion
		Add-Content "$([System.dateTime]::Now) - Orion unmanage" -path $LogFileName
		try {
			$ServerShorName = ($vCenter).split(".")[0]
			$CredentialOrion = new-object -typename System.Management.Automation.PSCredential -argumentlist $CredentialOrionNameSvcs, $CredentialOrionPassSvcs
			$Swis = Connect-Swis -host $swisTarget -Credential $CredentialOrion
			Set-UnmanageNode -NodeName $ServerShorName -Minute 30 -SwisConnection $Swis | out-null
		}
		catch {
			Add-Content "$([System.dateTime]::Now) - ERROR - UnmanageNode on Orion" -path $LogFileName
			$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
			Add-Content $MsgError -path $LogFileName
			$ScriptErrorList.Add("$($ServerShorName)-UnmanageNode", $MsgError)		
		}
		send-SMTPmail -to "EnterpriseOperationsCenter@technipenergies.com" -htmlBody "<b>Hi,<br>vCenter $($vCenter) will be restart now." -Subject $Subject -Start "$($MailStyle)"
		
		#Stop vCenter services
		RemoteServiceControl "eu001vc0012.tp.tpnet.intra" "VMware vSphere Update Manager Service" "Stop" 
		RemoteServiceControl "eu001vc0010.tp.tpnet.intra" "VMware vCenter Inventory Service" "Stop"  
		RemoteServiceControl "eu001vc0011.tp.tpnet.intra" "VMware VirtualCenter Management Webservices" "Stop" 
		RemoteServiceControl "eu001vc0011.tp.tpnet.intra" "VMware vSphere Profile-Driven Storage Service" "Stop" 
		RemoteServiceControl "eu001vc0011.tp.tpnet.intra" "VMware VirtualCenter Server" "Stop" 
		
		#Remove lock in Oracle DB
		$CommandLine = 'VCENTER55/vCenter55$0914@vCenterDB.world @"includ\vCenter-RemoveLock"'
		Add-Content "$([System.dateTime]::Now) - Starting includ\vCenter-RemoveLock.sql" -path $LogFileName
		$p = Start-Process -FilePath "sqlplus.exe" -ArgumentList "$($CommandLine)" -Wait -PassThru
		Move-Item $SQLResult -destination ([String]$ArchivePath + [String](get-date -format hhmm) + "-" + [String](([io.fileinfo]$SQLResult)).Name)
		if (($p.ExitCode -eq 0) -and ($p.HasExited)) {
			Add-Content "$([System.dateTime]::Now) - vCenter-RemoveLock.sql completed" -path $LogFileName
			$blFound = $true
		}
		else {
			Add-Content "$([System.dateTime]::Now) - vCenter-RemoveLock.sql failed" -path $LogFileName
			$ScriptErrorList.Add("Read Oracle DB", $p.ExitCode)
		}
		
		#Start vCenter services
		RemoteServiceControl "eu001vc0010.tp.tpnet.intra" "VMware vCenter Inventory Service" "Start"
		RemoteServiceControl "eu001vc0011.tp.tpnet.intra" "VMware VirtualCenter Server" "Start"
		RemoteServiceControl "eu001vc0011.tp.tpnet.intra" "VMware vSphere Profile-Driven Storage Service" "Start"
		RemoteServiceControl "eu001vc0011.tp.tpnet.intra" "VMware VirtualCenter Management Webservices" "Start"
		RemoteServiceControl "eu001vc0012.tp.tpnet.intra" "VMware vSphere Update Manager Service" "Start"
	}
}
catch {
	Add-Content "$([System.dateTime]::Now) - ERROR - Start-Process" -path $LogFileName
	$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
	Add-Content $MsgError -path $LogFileName
	$ScriptErrorList.Add("Start-Process error (2)", $MsgError)
}

if ($ScriptErrorList.count -gt 0) {
	$MsgError = [string]($ScriptErrorList.GetEnumerator() | ConvertTo-HTML -Fragment)
	send-SMTPmail -to $EmailScriptError -htmlBody $MsgError -Subject $SubjectError -Start "$($MailStyle)$($MailStartError)"
}

Add-Content "$([System.dateTime]::Now) - INFO - Reporting done" -path $LogFileName
Move-Item $LogFileName -destination "$ArchivePath"
