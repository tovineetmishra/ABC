
param(
 [string]$vCenter = "eu001vc0011.tp.tpnet.intra",
 [bool]$Debug = $false
)
[threading.thread]::CurrentThread.CurrentCulture = 'fr-FR'
if ($WorkingFolder -ne $null) { Set-Location -Path $WorkingFolder }


#***********************************************************************
#**************** Déclaration des variables ****************************
#***********************************************************************
$LogFileName 				= "$(get-location)\workingfile\VmwareLUNs-$($vCenter)-$(get-date -format yyyyMMdd-hhmmss).log"
$ArchivePath 				= "$(get-location)\history\$(get-date -format yyyyMMdd)\"
$ExportHbaCsvFileName		= "$(get-location)\workingfile\hba.csv"
$ExportDataStoreCsvFileName	= "$(get-location)\workingfile\ds.csv"
$ExportPathCsvFileName		= "$(get-location)\workingfile\Path.csv"

#*******************************************************
#**************** FUNCTIONS ****************************
#*******************************************************
. "..\PS-CommonLibrary\CommonFunction.ps1"

#*********************************************************
#************* MAIN **************************************
#*********************************************************
Add-Content "$([System.dateTime]::Now) - Starting Export-WWN-and-DS-ID $($vCenter)" -path $LogFileName
$CredvCenter = new-object -typename System.Management.Automation.PSCredential -argumentlist $RemoteServiceName, $CredPassSvcs

if (!(Get-Module -name VMware.VimAutomation.Core)) { Get-Module -ListAvailable VMware.VimAutomation.Core | Import-Module } 
if ((Test-Path -path $ArchivePath) -ne $True) { New-Item $ArchivePath -type Directory | Out-Null }

#Open vCenter connexion
try {
	Connect-VIServer $vCenter -Credential $credvCenter
	Add-Content "$([System.dateTime]::Now) - INFO - Connected to vcenter $($vCenter)" -path $LogFileName
}
catch {
	Add-Content "$([System.dateTime]::Now) - ERROR - Connected to vcenter $($vCenter)" -path $LogFileName
	$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
	Add-Content $MsgError -path $LogFileName
	$ScriptErrorList.Add("Connected to vcenter $($vCenter)", $MsgError)
}

$AllCluster = Get-cluster | Sort Name
$Cpt = 1
$DataStoreList = @()
$exportHBA = @()
$ExportPath = @()

foreach ($Cluster in $AllCluster) {
	Add-Content "$([System.dateTime]::Now) - INFO - Traitement de $($Cluster.Name)" -path $LogFileName
	try {
		$listHBA = $Cluster | Get-VMhost | Where { $_.PowerState -eq "PoweredOn" } | Get-VMHostHBA -Type FibreChannel | Select VMHost,Device,@{N="WWN";E={"{0:X}"-f$_.PortWorldWideName}} | Sort VMhost,Device
		$exportHBA += $listHBA
	}
	catch {
		Add-Content "$([System.dateTime]::Now) - ERROR - Moving file $($FileToMove.Path)" -path $LogFileName
		$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
		Add-Content $MsgError -path $LogFileName
		$ScriptErrorList.Add("ExportHbaFileName", $MsgError)		
	}
	$DataStoreList += Get-Datastore -VMHost ($Cluster | Get-VMhost | Where { $_.PowerState -eq "PoweredOn" })

	foreach ($esx in ($Cluster | Get-VMhost | Where { $_.PowerState -eq "PoweredOn" } )) {
		$PathList = Get-VMHost $esx.name | Get-ScsiLun -LunType disk | where {($_.IsLocal -eq $False) -and ($_.CapacityMB -gt 10)} | Select-Object CanonicalName, CapacityMB, RuntimeName, Model, MultipathPolicy, Id
		$ExportPath += $PathList
	}
	$cpt += 1
	if (($cpt -gt 3) -and $Debug) { 
		Add-Content "$([System.dateTime]::Now) - INFO - Debug break after 3" -path $LogFileName
		break
	}
}

$exportHBA | Export-Csv -path $ExportHbaCsvFileName -Delimiter ";" -Force -NoTypeInformation
$DataStoreList | Export-Csv -path $ExportDataStoreCsvFileName -Delimiter ";" -Force -NoTypeInformation
$ExportPath | Export-Csv -path $ExportPathCsvFileName -Delimiter ";" -Force -NoTypeInformation


Add-Content "$([System.dateTime]::Now) - INFO - Reporting done" -path $LogFileName
Move-Item $LogFileName -destination "$ArchivePath"
Disconnect-VIServer -Confirm:$false