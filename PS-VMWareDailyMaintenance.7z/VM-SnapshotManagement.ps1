#VM-SnapshotManagement v1.5
#Remove Windows Update Snapshot older than 2 days, all snapshot older than 30 days and export snapshots older than 7 days.
#Subtask sent by VMwareDailyMaintenance.ps1

#Update 2017-11-02, XPr:
#	-> Migrate to eu001vc0035
#Update 2017-03-21, XPr:
#	-> Add versionning in log file name
#	-> RunAsync activation and limit to 10 removing task in a same time
#INC1920235 LOC 124 has been modified and added one more condition
param(
	[string]$WorkingFolder = $null,
	[string]$JobName = $null,
    [string]$vCenter = "eu001vc0028.tp.tpnet.intra",
	[bool]$FullRemove = $false,
	[bool]$Debug = $false
)
[threading.thread]::CurrentThread.CurrentCulture = 'fr-FR'
if ($WorkingFolder -ne $null) { Set-Location -Path $WorkingFolder }

#**********************************************************************
#**************** CONSTANTS and VARIABLES  ****************************
#**********************************************************************
$ScriptVersion 				= "v1.5"
$LogFileName 				= "$(get-location)\workingfile\VM-SnapshotManagement-$($vCenter)-$($ScriptVersion)-$(get-date -format yyyyMMdd-hhmmss).log"
$ArchivePath 				= "$(get-location)\history\$(get-date -format yyyyMMdd)\"
$ReportSnapShot				= "$(get-location)\workingfile\VM-SnapshotManagement-Report-$($vCenter)-$($ScriptVersion).csv"
$ReportErrorRemoveSnapShot	= "$(get-location)\workingfile\VM-SnapshotManagement-Error-$($vCenter)-$($ScriptVersion).csv"
$ExcludeWords 				= "*replica*","*clone*","eu120vm0005.tp.tpnet.intra","eu0120vm0007.tp.tpnet.intra","eu099vm9001.tp.tpnet.intra","eu120vm0006.tp.tpnet.intra","eu099vm*","*remove*","*deleted*","eu003vm0434*","eu003vm0299*","eu120vm*","*eu120vm0006*","*eu120vm0005*","*eu099vm9001*"

$MaxDay 					= -30
$WindowsMaxDay 				= -1
$ReportsMaxDays				= -3
$MaxRemoveInSameTime		= 30

#*******************************************************
#**************** FUNCTIONS ****************************
#*******************************************************
. "..\PS-CommonLibrary\CommonFunction.ps1"

#*********************************************************
#************* MAIN **************************************
#*********************************************************
Add-Content "$([System.dateTime]::Now) - Starting VM-RemoveSnapshot for $($vCenter) [Debug=$($Debug), FullRemove=$($FullRemove)]" -path $LogFileName
$CredvCenter = new-object -typename System.Management.Automation.PSCredential -argumentlist $RemoteServiceName, $CredPassSvcs
if ((Test-Path -path $ArchivePath) -ne $True) { New-Item $ArchivePath -type Directory }

#Chargement du PowerCli si n�cessaire
if (!(Get-Module -name VMware.VimAutomation.Core)) { Get-Module -ListAvailable VMware.VimAutomation.Core | Import-Module } 
try {
	Add-Content "$([System.dateTime]::Now) - INFO - Connect to vCenter: $($vCenter)" -path $LogFileName
	Connect-VIServer $vCenter -Credential $credvCenter | out-null
}
catch {	AddTrackError -ShortName "Connect to vCenter: $($vCenter)" -Severity 0 -ErrRecord $_ }

$SnapshotToRemove = @()
try {
	Add-Content "$([System.dateTime]::Now) - INFO - Get-Snapshot created by Windows Update and Hardware Version Upgrade" -path $LogFileName
	[array]$SnapshotWindowsUpdate = Get-VM | Get-Snapshot -name "*Before Windows Update" | Where { $_.Created -lt (Get-Date).AddDays($WindowsMaxDay) }
	$SnapshotWindowsUpdate += Get-VM | Get-Snapshot -name "*Before Hardware Version Upgrade" | Where { $_.Created -lt (Get-Date).AddDays($WindowsMaxDay) }
	if ($FullRemove) {
		Add-Content "$([System.dateTime]::Now) - INFO - Get-Snapshot older than $($MaxDay) days" -path $LogFileName
		$SnapshotToOld = Get-VM | Get-Snapshot | Where {($_.Created -lt (Get-Date).AddDays($MaxDay)) -and !($_.VM.Notes -like "*master*") -and !($_.Name -like "*_replica")}
		$SnapshotToRemove = $SnapshotWindowsUpdate + $SnapshotToOld
	}
	else {
		$SnapshotToRemove = $SnapshotWindowsUpdate
	}
	Add-Content "$([System.dateTime]::Now) - INFO - $($SnapshotToRemove.Count) to remove" -path $LogFileName
}
catch { AddTrackError -ShortName "Get-Snapshot-$($vCenter)" -Severity 0 -ErrRecord $_ }

$RemoveSnapshotTask = @()
$Cpt = 1
foreach ($OneSnap in $SnapshotToRemove) {
	if (!($ExcludeWords | foreach { $OneSnap.VM -like "$($_)" } | Sort-Object | Select -Last 1)) {
		try {
			Add-Content "$([System.dateTime]::Now) - INFO - $($Cpt)/$($SnapshotToRemove.Count) Remove snapshot for $($OneSnap.VM): $($OneSnap.Name)" -path $LogFileName
			$RemoveSnapshotTask += $OneSnap | Remove-Snapshot -RunAsync -Confirm:$false
			Start-Sleep -s 1
		}
		catch { AddTrackError -ShortName "Remove-Snapshot-$($OneSnap.VM)" -Severity 0 -ErrRecord $_	}
				
		While ((Get-Task -Status Running | Where { $_.Name -eq "RemoveSnapshot_Task" }).Count -gt $MaxRemoveInSameTime) {
			Get-Task -Status Running | Where { $_.Name -eq "RemoveSnapshot_Task" } | Sort-Object -Property StartTime | %{
				Add-Content "$([System.dateTime]::Now) - INFO - $($_.Id);$($_.Name);$($_.ObjectId);$($_.StartTime);$($_.PercentComplete)%" -path $LogFileName
			}
			Add-Content "$([System.dateTime]::Now) - INFO - Wait 10s" -path $LogFileName
			Start-Sleep -s 10
		}
	}
	else { Add-Content "$([System.dateTime]::Now) - INFO - $($OneSnap.VM) exclude by VM Name" -path $LogFileName }
	$Cpt += 1
	if ($Debug -and ($Cpt -gt 50)) { break }
}

$Cpt += 0
While ((Get-Task -Status Running | Where { $_.Name -eq "RemoveSnapshot_Task" }).Count -gt 0) {
	Get-Task -Status Running | Where { $_.Name -eq "RemoveSnapshot_Task" } | Sort-Object -Property StartTime | %{
		Add-Content "$([System.dateTime]::Now) - INFO - $($_.Id);$($_.Name);$($_.ObjectId);$($_.StartTime);$($_.PercentComplete)%" -path $LogFileName
	}
	Add-Content "$([System.dateTime]::Now) - INFO - Wait 20s" -path $LogFileName
	foreach ($SnapTask in $RemoveSnapshotTask) { if ([array](Get-Task | ?{ $_.Id -eq $SnapTask.Id }).Count -gt 0) { $SnapTask = Get-Task | ?{ $_.Id -eq $SnapTask.Id } } }
	Start-Sleep -s 20
	$Cpt += 1
	if ($Cpt -gt 90) { break }
}

#Report task result
try {
	$ReportingError = @()
	foreach ($SnapTask in $RemoveSnapshotTask) { 
		if ((Get-Task | ?{ $_.Id -eq $SnapTask.Id }).State -eq "Error") {
			$NewLine = [pscustomobject]@{vCenter=$vCenter;VMName=((Get-VM -id $SnapTask.ObjectId).Name);State=(Get-Task | ?{ $_.Id -eq $SnapTask.Id }).State;PercentComplete=(Get-Task | ?{ $_.Id -eq $SnapTask.Id }).PercentComplete;StartTime=$SnapTask.StartTime;FinishTime=(Get-Task | ?{ $_.Id -eq $SnapTask.Id }).FinishTime;Task=$SnapTask.Description}
			$ReportingError += $NewLine
		}
	}
	if ($ReportingError.Count -gt 0) { $ReportingError | Export-Csv -path $ReportErrorRemoveSnapShot -Delimiter ";" -Force -NoTypeInformation }
}
catch { AddTrackError -ShortName "Report task result" -Severity 0 -ErrRecord $_ }

#Reporting
try {
	[array]$SnapshotsToReport = Get-VM | Get-Snapshot | Where { $_.Created -lt (Get-Date).AddDays($ReportsMaxDays) -and $_.Name -notlike "*Master*"  }
	if ($SnapshotsToReport.Count -gt 0) { $SnapshotsToReport | Select @{Name="vCenter";Expression={$vCenter}}, VM, Name, Created, SizeGB, ParentSnapshot | Export-Csv -path $ReportSnapShot -Delimiter ";" -Force -NoTypeInformation }
}
catch { AddTrackError -ShortName "Reporting" -Severity 0 -ErrRecord $_ }

Add-Content "$([System.dateTime]::Now) - INFO - Batch end" -path $LogFileName
Move-Item $LogFileName -destination "$ArchivePath" -force
Disconnect-VIServer -Confirm:$False

return $global:ScriptErrorArray