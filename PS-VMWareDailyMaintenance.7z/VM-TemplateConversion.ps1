#VM-TemplateConversion v1.0
#Convert Template for backup issue
#Subtask sent by VMwareDailyMaintenance.ps1

param(
	[string]$WorkingFolder = $null,
	[string]$JobName = $null,
    [string]$vCenter = "eu001vc0011.tp.tpnet.intra",
	[string]$Action = "ToTemplate", # "ToVM"
	[bool]$Debug = $false
)
[threading.thread]::CurrentThread.CurrentCulture = 'fr-FR'
if ($WorkingFolder -ne $null) { Set-Location -Path $WorkingFolder }

#**********************************************************************
#**************** CONSTANTS and VARIABLES  ****************************
#**********************************************************************
$ScriptVersion 				= "v1.0"
$LogFileName 				= "$(get-location)\workingfile\VM-TemplateConversion-$($vCenter)-$($ScriptVersion)-$(get-date -format yyyyMMdd-hhmmss).log"
$ArchivePath 				= "$(get-location)\history\$(get-date -format yyyyMMdd)\"
$ExcludeWords 				= "*replica*", "*clone*", "eu099vm*", "*remove*", "*deleted*", "eu003vm0434*", "eu003vm0299*"

#*******************************************************
#**************** FUNCTIONS ****************************
#*******************************************************
. "..\PS-CommonLibrary\CommonFunction.ps1"

#*********************************************************
#************* MAIN **************************************
#*********************************************************
Add-Content "$([System.dateTime]::Now) - Starting VM-TemplateConversion on $($vCenter) for action $($Action) [Debug=$($Debug), FullRemove=$($FullRemove)]" -path $LogFileName
$CredvCenter = new-object -typename System.Management.Automation.PSCredential -argumentlist $RemoteServiceName, $CredPassSvcs
if ((Test-Path -path $ArchivePath) -ne $True) { New-Item $ArchivePath -type Directory }
if (!(Get-Module -name VMware.VimAutomation.Core)) { Get-Module -ListAvailable VMware.VimAutomation.Core | Import-Module } 
	
try {
	$CurrentVC = Connect-VIServer $vCenter -Credential $credvCenter
	Add-Content "$([System.dateTime]::Now) - INFO - Connected to vcenter $($vCenter)" -path $LogFileName
}
catch {	AddTrackError -ShortName "Connect-VIServer" -Severity 0 -ErrRecord $_ }
	
try {
	if ($Action -eq "ToTemplate") { $TemplateListToConvert = Get-VM -Name "*EDC*" }
	if ($Action -eq "ToVM") { $TemplateListToConvert = Get-Template -Name "*EDC*" }
	Add-Content "$([System.dateTime]::Now) - INFO - Template in scope $($TemplateListToConvert.Count)" -path $LogFileName
}
catch {	AddTrackError -ShortName "Get-VM or Get-Template" -Severity 0 -ErrRecord $_ }	

foreach ($TemplateToConvert IN $TemplateListToConvert) {
	try {
		Add-Content "$([System.dateTime]::Now) - INFO - Starting Conversion of '$($TemplateToConvert.Name)', power state is '$($TemplateToConvert.PowerState)'" -path $LogFileName
		if (($Action -eq "ToTemplate") -and ($TemplateToConvert.PowerState -ne "PoweredOn")) {
			$Convert = Get-VM -Name $TemplateToConvert.Name | Set-VM -totemplate -confirm:$false
			Add-Content "$([System.dateTime]::Now) - $($TemplateToConvert.Name): Convert in template" -path $LogFileName
		}
		elseif (($Action -eq "ToVM") -and ($TemplateToConvert.PowerState -ne "PoweredOn")) {
			$Convert = Get-Template -Name  $TemplateToConvert.Name | Set-Template -tovm -confirm:$false
			Add-Content "$([System.dateTime]::Now) - INFO - $($TemplateToConvert.Name): Convert in VM" -path $LogFileName
		}
		else {
			Add-Content "$([System.dateTime]::Now) - ERROR - Wrong Action or PowerState" -path $LogFileName
			AddTrackError -ShortName "$($TemplateToConvert.Name): Wrong Action or PowerState of Template" -Severity 0 -ErrRecord $_
		}
	}
	catch {	AddTrackError -ShortName "Convert" -Severity 0 -ErrRecord $_ }
	if ($Debug) { break }
}

Add-Content "$([System.dateTime]::Now) - INFO - Batch end" -path $LogFileName
Move-Item $LogFileName -destination "$ArchivePath" -force
Disconnect-VIServer -Confirm:$False

return $global:ScriptErrorArray