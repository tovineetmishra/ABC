#DS-SettingCheck
#Check Round Robin on dataStore and RR setting to iops=1
#Subtask sent by VMwareDailyMaintenance.ps1

#- Command Line : C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe
#- Argument Line : -command "E:\PS-Scripts\PS-VMWareDailyMaintenance\DS-SettingCheck.ps1 -vCenter "eu001vc0011.tp.tpnet.intra" -TypeAction "repair""
#- Start in : E:\PS-Scripts\PS-VMWareDailyMaintenance\
param(
	[string[]]$WorkingFolder = $null,
    [string[]]$vCenter = "eu001vc0011.tp.tpnet.intra",
	[string[]]$TypeAction = "Check",
	[bool]$Debug = $false
)
[threading.thread]::CurrentThread.CurrentCulture = 'fr-FR'
if ($WorkingFolder -ne $null) { Set-Location -Path "$($WorkingFolder)" }

#***********************************************************************
#**************** D�claration des variables ****************************
#***********************************************************************
$LogFileName 					= "$(get-location)\workingfile\DS-SettingCheck-$($vCenter)-$(get-date -format yyyyMMdd-hhmmss).log"
$ExportCsvFileName 				= "$(get-location)\workingfile\DS-SettingCheck-report-$($vCenter).csv"
$ArchivePath 					= "$(get-location)\history\$(get-date -format yyyyMMdd)\"

$ScriptErrorMailStart			= "<b>Hi,<br> DataStore setting check:</b><br/><br/>`n`n"
$ScriptErrorSubject 			= "[EDC-VmwareCheck][EDC-Script-Failed] DataStore setting check on $($vCenter)"

$global:exportList = @() # array for export

#*******************************************************
#**************** FUNCTIONS ****************************
#*******************************************************
. "..\PS-CommonLibrary\CommonFunction.ps1"

Function AddToList($EsxName, $TypeSet, $detailObject1, $detailObject2, $ReturnAction) {
	$output = "" | Select-Object VMHost, TypeSetting, detailObject1, detailObject2, ReturnAction
	$output.VMHost = $EsxName
	$output.TypeSetting = $TypeSet
	$output.detailObject1 = $detailObject1
	$output.detailObject2 = $detailObject2
	$output.ReturnAction = $ReturnAction
	$global:exportList += $output
}

#*********************************************************
#************* MAIN **************************************
#*********************************************************
Add-Content "$([System.dateTime]::Now) - Starting DS-SettingCheck - $($TypeAction)" -path $LogFileName
$CredvCenter = new-object -typename System.Management.Automation.PSCredential -argumentlist $RemoteServiceName, $CredPassSvcs

#Chargement du PowerCli si n�cessaire
if (!(Get-Module -name VMware.VimAutomation.Core)) { Get-Module -ListAvailable VMware.VimAutomation.Core | Import-Module } 

#Open vCenter connexion
try {
	$ViServer = Connect-VIServer $vCenter -Credential $CredvCenter
	Add-Content "$([System.dateTime]::Now) - INFO - Connected to vcenter $($vCenter)" -path $LogFileName
}
catch {
	Add-Content "$([System.dateTime]::Now) - ERROR - Connected to vcenter $($vCenter)" -path $LogFileName
	$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
	Add-Content $MsgError -path $LogFileName
	$ScriptErrorList.Add("Connected to vcenter $($vCenter)", $MsgError)
}

#Open all ESXi
try {
	$AllEsxi = Get-VMHost -Server $ViServer | Where { $_.PowerState -eq "PoweredOn" } | Sort Name
	Add-Content "$([System.dateTime]::Now) - INFO - Open ESXi list ($($AllEsxi.Count))" -path $LogFileName
}
catch {
	Add-Content "$([System.dateTime]::Now) - ERROR - Open all ESXi" -path $LogFileName
	$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
	Add-Content $MsgError -path $LogFileName
	$ScriptErrorList.Add("Open all ESXi", $MsgError)
}

$BlFound = $false
$Cpt = 1
if ($AllEsxi) {
	foreach ($esx in $AllEsxi) {
		Add-Content "$([System.dateTime]::Now) - INFO - treatment of $($esx.name) $($Cpt/$AllEsxi.Count)" -path $LogFileName
		"Round-Robin Setting"
		try {
			$PathList = Get-VMHost $esx.name | Get-ScsiLun -LunType disk | where {($_.IsLocal -eq $False) -and ($_.MultipathPolicy -ne "RoundRobin") -and ($_.CapacityMB -gt 10)} | Select-Object CanonicalName, CapacityMB, RuntimeName, Model, MultipathPolicy, Id
			foreach ($DSPath in $PathList) {
				if ($DSPath.CanonicalName -ne $null) {
					if ($TypeAction -eq "Repair") {
						Add-Content "$([System.dateTime]::Now) - INFO - modification de $($DSPath.CanonicalName)" -path $LogFileName
						Get-ScsiLun -CanonicalName $DSPath.CanonicalName -VmHost $esx.name | Set-ScsiLun -MultipathPolicy RoundRobin
						AddToList $esx.name "RR" $DSPath.RuntimeName $DSPath.CanonicalName "Repair"
					}
					else {
						AddToList $esx.name "RR" $DSPath.RuntimeName $DSPath.CanonicalName "Check"
					}
					$BlFound = $true
				}
			}
		}
		catch {
			Add-Content "$([System.dateTime]::Now) - ERROR - $($esx.name) - Round-Robin Setting" -path $LogFileName
			$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
			Add-Content $MsgError -path $LogFileName
			$ScriptErrorList.Add("$($esx.name) - Round-Robin Setting", $MsgError)
		}
		$esxcli = Get-EsxCli -VMHost $esx
		$DetachedList = $esxcli.storage.core.device.detached.list()
		"Removing detached"
		if ($DetachedList.Count -gt 0) {
			try {
				Add-Content "$([System.dateTime]::Now) - INFO - Remove detached device $($DetachedList.Count)" -path $LogFileName
				$DetachedList | %{ $esxcli.storage.core.device.detached.remove("$($_.DeviceUID)") }
			}
			catch {
				Add-Content "$([System.dateTime]::Now) - ERROR - $($esx.name) - Detach" -path $LogFileName
				$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
				Add-Content $MsgError -path $LogFileName
				$ScriptErrorList.Add("$($esx.name) - Detach", $MsgError)			
			}
		}
		"IOPS setting"
		try {
			$esxcli.storage.nmp.device.list() | where { $_.PathSelectionPolicy -eq "VMW_PSP_RR" -and $_.PathSelectionPolicyDeviceConfig -match "iops=1" } | %{
				if ($TypeAction -eq "Repair") {
					Add-Content "$([System.dateTime]::Now) - INFO - modification iops de $($_.Device)" -path $LogFileName
					if (($esxcli.system.version.get()).Version -eq "5.0.0") {
						$esxcli.storage.nmp.psp.roundrobin.deviceconfig.set(0,$_.Device,[long]50,"iops",$null)
					}
					else {
						$esxcli.storage.nmp.psp.roundrobin.deviceconfig.set(0, 1,$_.Device,[long]50,"iops",$null)
					}
					AddToList $esx.name "IOPS" $_.Device $_.PathSelectionPolicyDeviceConfig "Repair"
				}
				else {
					AddToList $esx.name "IOPS" $_.Device $_.PathSelectionPolicyDeviceConfig "Check"
				}
				$BlFound = $true
			}
		}
		catch {
			Add-Content "$([System.dateTime]::Now) - ERROR - $($esx.name) - IOPS setting" -path $LogFileName
			$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
			Add-Content $MsgError -path $LogFileName
			$ScriptErrorList.Add("$($esx.name) - IOPS setting", $MsgError)
		}		
		$cpt += 1
		if (($cpt -gt 5) -and $Debug) { 
			Add-Content "$([System.dateTime]::Now) - INFO - Debug break after 5" -path $LogFileName
			break
		}
	}
}

if ($BlFound -eq $true) {
	Add-Content "$([System.dateTime]::Now) - INFO - Exporting csv file." -path $LogFileName
	$global:exportList | Export-Csv -path $ExportCsvFileName -Delimiter ";" -Force -NoTypeInformation
}
else {
	Add-Content "$([System.dateTime]::Now) - INFO - all DS setting OK" -path $LogFileName
}

if ($ScriptErrorList.count -gt 0) {
	$MsgError = [string]($ScriptErrorList.GetEnumerator() | ConvertTo-HTML -Fragment)
	Send-SMTPmail -to $EmailScriptError -htmlBody $MsgError -Subject $ScriptErrorSubject -Start "$($MailStyle)$($ScriptErrorMailStart)" -FilesAttachment $LogFileName
}

Add-Content "$([System.dateTime]::Now) - INFO - Reporting done" -path $LogFileName
Move-Item $LogFileName -destination "$ArchivePath"
Disconnect-VIServer * -Confirm:$false