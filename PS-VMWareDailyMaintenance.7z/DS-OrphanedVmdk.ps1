#DS-OrphanedVmdk
#Copy orphaned VMDK found in all datastore to /vMotion
#Subtask sent by VMwareDailyMaintenance.ps1

#- Command Line : C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe
#- Argument Line : -command "E:\PS-Scripts\PS-VMWareDailyMaintenance\DS-OrphanedVmdk.ps1 -vCenter "eu001vc0007.tp.tpnet.intra""
#- Start in : E:\PS-Scripts\PS-VMWareDailyMaintenance\
param(
	[string[]]$WorkingFolder = $null,
    [string[]]$vCenter = "eu001vc0011.tp.tpnet.intra",
	[bool]$CheckOnly = $true,
	[bool]$Debug = $false
)
[threading.thread]::CurrentThread.CurrentCulture = 'fr-FR'
if ($WorkingFolder -ne $null) {
	set-location -Path "$($WorkingFolder)"
}

#***********************************************************************
#**************** D�claration des variables ****************************
#***********************************************************************
$LogFileName 				= "$(get-location)\workingfile\DS-OrphanedVmdk-$($vCenter)-$(get-date -format yyyyMMdd-hhmmss).log"
$ExportFileName 			= "$(get-location)\workingfile\DS-OrphanedVmdk-report-$($vCenter).csv"
$ArchivePath 				= "$(get-location)\history\$(get-date -format yyyyMMdd)\"

$ScriptErrorMailStart		= "<b>Hi,<br> Orphan vmdk check:</b><br/><br/>`n`n"
$ScriptErrorSubject 		= "[EDC-VmwareCheck][EDC-Script-Failed] Orphan vmdk check on $($vCenter)"

$Rapport = @()

#*******************************************************
#**************** FUNCTIONS ****************************
#*******************************************************
. "..\PS-CommonLibrary\CommonFunction.ps1"

#*********************************************************
#************* MAIN **************************************
#*********************************************************
Add-Content "$([System.dateTime]::Now) - Starting DS-OrphanedVmdk on $($vCenter)" -path $LogFileName
$CredvCenter = new-object -typename System.Management.Automation.PSCredential -argumentlist $RemoteServiceName, $CredPassSvcs

if ((Test-Path -path $ArchivePath) -ne $True) {
	New-Item $ArchivePath -type Directory
}

#Loading PowerCli
if (-Not (Get-PSSnapin VMware.VimAutomation.Core -WarningAction SilentlyContinue -ErrorAction SilentlyContinue) ) {
	Add-Content "$([System.dateTime]::Now) - INFO - Loading PowerCLI" -path $LogFileName
	Add-PSSnapin VMware.VimAutomation.Core -ErrorAction SilentlyContinue
}

#Open vCenter connexion
try {
	Connect-VIServer $vCenter -Credential $credvCenter | out-null
	Add-Content "$([System.dateTime]::Now) - INFO - Connected to vcenter $($vCenter)" -path $LogFileName
}
catch {
	Add-Content "$([System.dateTime]::Now) - ERROR - Connected to vcenter $($vCenter)" -path $LogFileName
	$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
	Add-Content $MsgError -path $LogFileName
	$ScriptErrorList.Add("Connected to vcenter $($vCenter)", $MsgError)
}

#Open All disk connected
try {
	$Disques = Get-View -ViewType VirtualMachine | % {$_.Layout} | % {$_.Disk} | % {$_.DiskFile}
	Add-Content "$([System.dateTime]::Now) - INFO - Open all virtual disk)" -path $LogFileName
}
catch {
	Add-Content "$([System.dateTime]::Now) - ERROR - Open all virtual disk" -path $LogFileName
	$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
	Add-Content $MsgError -path $LogFileName
	$ScriptErrorList.Add("Open all virtual disk", $MsgError)
}

#Open All DataStores
try {
	$arrDS = Get-Datastore | Sort-Object -property Name | Where { !($_.Name -match "vMotion") -and !($_.Name -match "TemplateStore") -and !($_.Name -match "Boot") }
	Add-Content "$([System.dateTime]::Now) - INFO - Open all DataStore disk" -path $LogFileName
}
catch {
	Add-Content "$([System.dateTime]::Now) - ERROR - Open all DataStore" -path $LogFileName
	$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
	Add-Content $MsgError -path $LogFileName
	$ScriptErrorList.Add("Open all DataStore", $MsgError)
}

$blFound = $False
$Cpt = 1
foreach ($strDatastore in $arrDS) {
	Add-Content "$([System.dateTime]::Now) - INFO - $($strDatastore.Name)" -path $LogFileName
	try {
		$ds = Get-Datastore -Name $strDatastore.Name | % {Get-View $_.Id}
		$fileQueryFlags = New-Object VMware.Vim.FileQueryFlags
		$fileQueryFlags.FileSize = $true
		$fileQueryFlags.FileType = $true
		$fileQueryFlags.Modification = $true
		$searchSpec = New-Object VMware.Vim.HostDatastoreBrowserSearchSpec
		$searchSpec.details = $fileQueryFlags
		$searchSpec.matchPattern = "*.vmdk"
		$searchSpec.sortFoldersFirst = $true
		$dsBrowser = Get-View $ds.browser
		$rootPath = "["+$ds.summary.Name+"]"
		if ($dsBrowser.Client.Version -eq "Vim4") {
			$searchSpec = [VMware.Vim.VIConvert]::ToVim4($searchSpec)
			$searchSpec.details.fileOwnerSpecified = $true
			$dsBrowserMoRef = [VMware.Vim.VIConvert]::ToVim4($dsBrowser.MoRef);
			$searchTaskMoRef = $dsBrowser.Client.VimService.SearchDatastoreSubFolders_Task($dsBrowserMoRef, $rootPath, $searchSpec)
			$searchResult = [VMware.Vim.VIConvert]::ToVim($dsBrowser.WaitForTask([VMware.Vim.VIConvert]::ToVim($searchTaskMoRef)))
		} 
		else {
			$searchResult = $dsBrowser.SearchDatastoreSubFolders($rootPath, $searchSpec)
		}

		foreach ($folder in $searchResult) 	{
			foreach ($fileResult in $folder.File) {
				if ($fileResult.Path) {
					if ((-not ($disques -contains ($folder.FolderPath + $fileResult.Path))) -and (-not ($fileResult.Path -like '*-ctk*'))){
						$row = "" | Select DS, Path, File, Size, ModDate, Host
						$row.DS = $strDatastore.Name
						$row.Path = $folder.FolderPath
						$row.File = $fileResult.Path
						$row.Size = $fileResult.FileSize
						$row.ModDate = $fileResult.Modification
						$row.Host = (Get-View $ds.Host[0].Key).Name
						$rapport += $row
						$blFound = $true
					}
				}
			}
		}
	}
	catch {
		Add-Content "$([System.dateTime]::Now) - ERROR - $($strDatastore.Name)" -path $LogFileName
		$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
		Add-Content $MsgError -path $LogFileName
		$ScriptErrorList.Add("Search in $($strDatastore.Name)", $MsgError)
	}
	
	$cpt += 1
	if (($cpt -gt 25) -and $Debug) { 
		Add-Content "$([System.dateTime]::Now) - INFO - Debug break after 15" -path $LogFileName
		break
	}
}

if ($blFound) {
	Add-Content "$([System.dateTime]::Now) - INFO - Reporting by mail" -path $LogFileName
	$rapport | Export-Csv -path $ExportFileName -Delimiter ";" -Force -NoTypeInformation 
	if (!$CheckOnly) {
		try {
			$vMotionDS = Get-Datastore "EDC-Live-vMotion-vPlex"
			New-PSDrive -Location $vMotionDS -Name vMotionDrive -PSProvider VimDatastore -Root "\" | out-null
		}
		catch {
			Add-Content "$([System.dateTime]::Now) - ERROR - Attach vMotionDrive" -path $LogFileName
			$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
			Add-Content $MsgError -path $LogFileName
			$ScriptErrorList.Add("Attach vMotionDrive", $MsgError)
		}
		foreach ($FileToMove in $rapport) {
			Add-Content "$([System.dateTime]::Now) - INFO - Moving file $($FileToMove.File)" -path $LogFileName
			try {
				$Path = ($FileToMove.Path.Split(" ")[1]).Replace('/','\')
				$vSourceDS = Get-Datastore $FileToMove.DS
				New-PSDrive -Location $vSourceDS -Name DSSource -PSProvider VimDatastore -Root "\" | out-null
				Move-Item "DSSource:\$($Path)$($FileToMove.File)" -Destination "vMotionDrive:\OrphanedVmdk\"
				Remove-PSDrive DSSource
			}
			catch {
				Add-Content "$([System.dateTime]::Now) - ERROR - Moving file $($FileToMove.Path)" -path $LogFileName
				$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
				Add-Content $MsgError -path $LogFileName
				$ScriptErrorList.Add("Moving file $($FileToMove.Path)", $MsgError)			
			}
		}
		Remove-PSDrive vMotionDrive
	}
}
else {
	Add-Content "$([System.dateTime]::Now) - INFO - No action needed" -path $LogFileName
}

if ($ScriptErrorList.count -gt 0) {
	$MsgError = [string]($ScriptErrorList.GetEnumerator() | ConvertTo-HTML -Fragment)
	Send-SMTPmail -to $EmailScriptError -htmlBody $MsgError -Subject $ScriptErrorSubject -Start "$($MailStyle)$($ScriptErrorMailStart)" -FilesAttachment $LogFileName
}

Add-Content "$([System.dateTime]::Now) - INFO - Reporting done" -path $LogFileName
Move-Item $LogFileName -destination "$ArchivePath"
Disconnect-VIServer * -Confirm:$false