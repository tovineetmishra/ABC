#VMwareDailyMaintenance v1.5
#Daily maintenance for vCenter
#Schedule : Every day at 2:45
#Update 2017-11-02, XPr:
#	-> Migrate to eu001vc0035
#	-> Replace VM-RemoveSnapshot.ps1 by VM-SnapshotManagement.ps1
#Update 2017-03-23, XPr:
#	-> Add versionning in log file name
#	-> Datastore reclaim integration
#	-> Disable DS check (to be review)

#- Command Line : C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe
#- Argument Line : -NonInteractive -WindowStyle Hidden -Command "E:\PS-Scripts\PS-VMWareDailyMaintenance\VMwareDailyMaintenance.ps1"
#- Start in : E:\PS-Scripts\PS-VMWareDailyMaintenance\
param(
	[switch]$Debug
)

#***********************************************************************
#**************** D�claration des variables ****************************
#***********************************************************************
$ScriptVersion 						= "v1.5"

$ArchivePath 						= "$(get-location)\history\$(get-date -format yyyyMMdd)\"
$LogFileName 						= "$(get-location)\workingfile\VMwareDailyMaintenance-$($ScriptVersion)-$(get-date -format yyyyMMdd-hhmmss).log"

$DSOrphanedVmdkReport 				= "$(get-location)\workingfile\DS-OrphanedVmdk-report-*.csv"
$DSSettingReport 					= "$(get-location)\workingfile\DS-SettingCheck-report-*.csv"
$ApplyProfilReport					= "$(get-location)\workingfile\ESXi-ApplyProfil-report-*.csv"
$CheckTimeReport					= "$(get-location)\workingfile\ESXi-CheckTime-*.csv"
$ReportSnapShot 					= "$(get-location)\workingfile\VM-SnapshotManagement-Report-*.csv"
$ReportErrorSnapShot 				= "$(get-location)\workingfile\VM-SnapshotManagement-Error-*.csv"
$ReportAutomationLevel				= "$(get-location)\workingfile\VM-SDRSAutomationLevelCheck-Report-*.csv"

$SubjectReporting 					= "[EDC-Report] VMware health check"
$MailStartReporting 				= "<b>Hi,</b><br>`n`n"
$SubjectError						= "[EDC-VmwareMaintenance][Script-Failed] VMware health check"
$MailStartError 					= "<b>Hi,<br> Error in script VMwareDailyMaintenance.<br/><br/>`n`n"

$DailyCheck1 						= 0 #Sunday: Remove snaphost older than 30 days, export ESXi WWN, DS-SettingCheck, DS-OrphanedVmdk and check ESXi profile compliance and Check Time, REPORTING
$ConvertTemplateToVM				= 6 #Saturday morning, convert Template to VM for Networker backup
$ConvertVMtoTemplate				= 1 #Monday morning, rollback to Template 
$DailyCheck2 						= 2 #Tuesday: Datastore reclaim on XtremIO
$DailyCheck3 						= 3 #Wednesday: Export eu001vc0011 vCenter events and remove oldest
#Every days: Remove Snapshot (Windows update)

$MaxHourJobRunning					= 8
$AttachedFiles 						= @()
$MaxArrayReporting					= 10
$WaitJob 							= 30
$JobErrors							= @()

#*******************************************************
#**************** FUNCTIONS ****************************
#*******************************************************
. "..\PS-CommonLibrary\CommonFunction.ps1"
function CreateHtmlArray {
[CmdletBinding()]
	param (
		[Parameter(Position=0)] [ValidateNotNullOrEmpty()] [array]$ArrayList=$(throw "ArrayList is mandatory, please provide a value."),
		[Parameter(Position=1)] [ValidateNotNullOrEmpty()] [string]$Title=$(throw "Title is mandatory, please provide a value."), 
		[Parameter(Position=2)] [string]$Ticket=""
	)
	process {
		$ArrayHTML = [string]"<div class=SubTitle>$($Title)</div>`n"
		if ($ArrayList.Count -gt $MaxArrayReporting) {
			$ArrayHTML += [string]($ArrayList.GetEnumerator() | Select-Object -First $MaxArrayReporting | ConvertTo-HTML -Fragment)
			$ArrayHTML += "<div class=Normal>Only first $($MaxArrayReporting), see attached file to view more...</div>`n"
		}
		else {
			$ArrayHTML += [string]($ArrayList.GetEnumerator() | ConvertTo-HTML -Fragment)
		}
		$ArrayHTML += "</br>`n"
		if ($Ticket -ne "") { $ArrayHTML += "<div class=TicketRequest>=> $($Ticket)</div></br>`n" }
		return $ArrayHTML
	}
}

function FinishJob {
	[CmdletBinding()]
	param (
		[Parameter(Position=0)] [ValidateNotNullOrEmpty()] $OneJob=$(throw "Job is mandatory, please provide a value.")
	)
	Process {
		Add-Content "$([System.dateTime]::Now) - INFO - FinishJob: Job Id = $($OneJob.Id), Job name = $($OneJob.Name)" -path $LogFileName
		[array]$ReceiveJob = Receive-Job -Id $OneJob.Id
		Remove-Job -Id $OneJob.Id
		$ReceiveJob | %{ 
			if ($_) {
				if ($_.GetType().FullName -eq "System.Management.Automation.PSCustomObject") { $JobResult += [array]($_ | ?{ [string]$_.Severity -ne "" } | Select Script, ShortName, Severity, Description) }
				else { Add-Content "$([System.dateTime]::Now) - INFO - Receive Job: $($_)" -path $LogFileName }
			}
		}
		if ($JobResult.Count -gt 0) { return $JobResult } else { return $null }
		
	}
}

#*********************************************************
#************* MAIN **************************************
#*********************************************************
Add-Content "$([System.dateTime]::Now) - INFO - Starting VMwareDailyMaintenance [Debug=$($Debug.IsPresent)]" -path $LogFileName
if ((Test-Path -path $ArchivePath) -ne $True) { New-Item $ArchivePath -type Directory }
$ExecutionDay = [int](Get-Date).DayofWeek
#If sunday, we remove all snapshot older then 30 days, other day only snapshot generated by patching
if ($ExecutionDay -eq $DailyCheck1) { $RemoveAllSnapshot = $true } else { $RemoveAllSnapshot = $false }

#region Actions
#**************************************************************************************
#	Primary vCenter Stats/Log and restart
#**************************************************************************************
if ($ExecutionDay -eq $DailyCheck3) {
	Add-Content "$([System.dateTime]::Now) - INFO - Starting job vCenter-ExportEvent" -path $LogFileName
	$Job = Start-Job -name "vCenter-ExportEvent" -FilePath "$(get-location)\vCenter-ExportEvent.ps1" -ArgumentList "$(get-location)"
	Start-Sleep -s 5
}

#**************************************************************************************
#	VM Checking and update
#**************************************************************************************
Add-Content "$([System.dateTime]::Now) - INFO - Starting jobs VM-SnapshotManagement" -path $LogFileName

foreach ($vCenter in ($OnPremvCenterList | ?{ $_.EDCMaintenance })) {
	Add-Content "$([System.dateTime]::Now) - INFO - snapshot management for $($vCenter.Name)" -path $LogFileName
	$Job = Start-Job -name "VM-SnapshotManagement-$($vCenter.Name)" -FilePath "$(get-location)\VM-SnapshotManagement.ps1" -ArgumentList "$(get-location)", "VM-SnapshotManagement-$($vCenter.Name)", $vCenter.Name, $RemoveAllSnapshot, $Debug.IsPresent
	Start-Sleep -s 5
	#Stopping the SDRS script execution on the basis of the recomendation from the CC team
	#Add-Content "$([System.dateTime]::Now) - INFO - SDRS VM automatino setting  check for $($vCenter.Name)" -path $LogFileName
	#$Job = Start-Job -name "VM-SDRSAutomationLevelCheck-$($vCenter.Name)" -FilePath "$(get-location)\VM-SDRSAutomationLevelCheck.ps1" -ArgumentList "$(get-location)", "VM-SDRSAutomationLevelCheck-$($vCenter.Name)", $vCenter.Name, $Debug.IsPresent
	#Start-Sleep -s 5
}
if (($ExecutionDay -eq $ConvertTemplateToVM) -or ($ExecutionDay -eq $ConvertVMtoTemplate)) {
	if ($ExecutionDay -eq $ConvertTemplateToVM) { $ConvertAction = "ToVM"} else { $ConvertAction = "ToTemplate" }
	Add-Content "$([System.dateTime]::Now) - INFO - Starting jobs VM-TemplateConversion" -path $LogFileName
	foreach ($vCenter in ($OnPremvCenterList | ?{ $_.TemplateBackup })) {
		Add-Content "$([System.dateTime]::Now) - INFO - Template conversion for $($vCenter.Name)" -path $LogFileName
		$Job = Start-Job -name "VM-TemplateConversion-$($vCenter.Name)" -FilePath "$(get-location)\VM-TemplateConversion.ps1" -ArgumentList "$(get-location)", "VM-TemplateConversion-$($vCenter.Name)", $vCenter.Name, $ConvertAction, $Debug.IsPresent
		Start-Sleep -s 5
	}
}

#**************************************************************************************
#	ESXi/DataStore checking and update
#**************************************************************************************
if ($ExecutionDay -eq $DailyCheck2) {

	foreach ($vCenter in ($OnPremvCenterList | ?{ $_.DataStoreSpaceReclaim })) {
		Add-Content "$([System.dateTime]::Now) - INFO - Starting job DS-Reclaim for $($vCenter.Name)" -path $LogFileName
		$Job = Start-Job -name "DS-Reclaim-$($vCenter.Name)" -FilePath "$(get-location)\DS-Reclaim.ps1" -ArgumentList "$(get-location)", $vCenter.Name, "*XIO*", "VMFS", $Debug.IsPresent
		Start-Sleep -s 5
	}
}

if ($ExecutionDay -eq $DailyCheck1) {
	foreach ($vCenter in $OnPremvCenterList) {
		if ($vCenter.DataStoreSettingCheck) {
		    #Stopping the SDRS script execution on the basis of the recomendation from the CC team if you want to enable this remove the comments
			#Add-Content "$([System.dateTime]::Now) - INFO - Starting job DS-SettingCheck for $($vCenter.Name)" -path $LogFileName
			#$Job = Start-Job -name "DS-SettingCheck-$($vCenter.Name)" -FilePath "$(get-location)\DS-SettingCheck.ps1" -ArgumentList "$(get-location)", $vCenter.Name, "Check", $Debug.IsPresent
			#Start-Sleep -s 5
		}
		if ($vCenter.DataStoreOrphanedVmdk) {
			if (Test-Path $DSOrphanedVmdkReport) { Remove-Item $DSOrphanedVmdkReport }
			#Stopping the SDRS script execution on the basis of the recomendation from the CC team if you want to enable this remove the comments
			#Add-Content "$([System.dateTime]::Now) - INFO - Starting job DS-OrphanedVmdk for $($vCenter)" -path $LogFileName
			#$Job = Start-Job -name "DS-OrphanedVmdk-$($vCenter)" -FilePath "$(get-location)\DS-OrphanedVmdk.ps1" -ArgumentList "$(get-location)", $vCenter.Name, $true, $Debug.IsPresent
			#Start-Sleep -s 5
		}
		if ($vCenter.ESXiProfilCompliance) {
			Add-Content "$([System.dateTime]::Now) - INFO - Starting job ESXi-ProfilCompliance for $($vCenter.Name)" -path $LogFileName
			$Job = Start-Job -name "ESXi-ProfilCompliance-$($vCenter.Name)" -FilePath "$(get-location)\ESXi-ProfilCompliance.ps1" -ArgumentList "$(get-location)", $vCenter.Name, $null, $null, $true, $Debug.IsPresent
			Start-Sleep -s 50
			
			Add-Content "$([System.dateTime]::Now) - INFO - Starting job ESXi-CheckTime for $($vCenter.Name)" -path $LogFileName
			$Job = Start-Job -name "ESXi-CheckTime-$($vCenter.Name)" -FilePath "$(get-location)\ESXi-CheckTime.ps1" -ArgumentList "$(get-location)", $vCenter.Name
			Start-Sleep -s 5
		}
	}
}

Add-Content "$([System.dateTime]::Now) - INFO - Waiting completed jobs:" -path $LogFileName
While((Get-Job | where { $_.State -eq "Running" }).count -gt 0) {
	Start-Sleep -s $WaitJob
	Get-Job | where { $_.State -eq "Completed" } | %{
		Add-Content "$([System.dateTime]::Now) - INFO - job completed: $($_.Name) ($($_.State),$($_.Id))" -path $LogFileName
		$JobErrors += FinishJob -OneJob $_
	}
	Get-Job | where { $_.State -eq "Running" } | %{
		Add-Content "$([System.dateTime]::Now) - INFO - $($_.Name) still running, start $($_.PSBeginTime): $($_.JobStateInfo)" -path $LogFileName
		if (((Get-Date) - $_.PSBeginTime).TotalHours -gt $MaxHourJobRunning) {
			AddTrackError -ShortName $_.Name -Severity 0 -Description "job too long (greter than $($MaxHourJobRunning) hours). Killing job."
			$_ | Stop-Job
			Start-Sleep -s 5
			$_ | Remove-Job
		}
	}
}
Get-Job | where { $_.State -eq "Completed" } | %{
	Add-Content "$([System.dateTime]::Now) - INFO - job completed: $($_.Name) ($($_.State),$($_.Id))" -path $LogFileName
	$JobErrors += FinishJob -OneJob $_
}
$JobErrors
if (($JobErrors | ?{ $_.Severity -eq 0 }).Count -gt 0) { $global:ScriptErrorArray += $JobErrors | ?{ $_.Severity -eq 0 } }
if (($JobErrors | ?{ $_.Severity -eq 1 }).Count -gt 0) { $JobErrors | ?{ $_.Severity -eq 1 } | %{ Add-Content "$([System.dateTime]::Now) - WARNING - $($_.Script) - $($_.ShortName) - $($_.Description))" -path $LogFileName } }

Add-Content "$([System.dateTime]::Now) - INFO - All jobs completed" -path $LogFileName
#endregion

#**************************************************************************************
#	Reporting
#**************************************************************************************
$HtmlHeader = "<table width=100% class=PageHeader><tr><td width=25% class=PageHeader><img src='cid:TechnipFMC150.png' class=TechnipFMCLogo></td><td width=50% class=PageTitle>Infrastructure & Operations - European Datacenter<br/>VMware health check</td><td width=25% class=PageHeader>&nbsp;</td></tr></table><br/>"
$VMSection = "<div class=SectionTitle>Virtuals machines report:</div>`n"
$HypervisorSection = "<div class=SectionTitle>Hypervisors report:</div>`n"

if (Test-Path $ReportErrorSnapShot) {
	Add-Content "$([System.dateTime]::Now) - INFO - Reporting error when removing snapshots" -path $LogFileName
	$ListImport = @()
	$Reports = Get-ChildItem $ReportErrorSnapShot
	foreach ($csv in $Reports ) {
		$temp = [array](Import-csv -Path $csv -Delimiter ";")
		$ListImport += $temp
		$AttachedFiles += $csv	
	}
	if ($ListImport) {
		$ReportErrorSnapShotHtml += CreateHtmlArray -ArrayList $ListImport -Title "Snapshots failed to be removed:" -Ticket "Create INC ticket '[EDC-Virtualization] - Snapshots failed to be removed' with Priority=3, Category=Service Delivery, Assignment Group=EDC-Virtualization-L2"
		$blMailToTeam = $true
	}
}

if (Test-Path $ReportSnapShot) {
	Add-Content "$([System.dateTime]::Now) - INFO - Reporting snapshots" -path $LogFileName
	$ListImport = @()
	$Reports = Get-ChildItem $ReportSnapShot
	foreach ($csv in $Reports ) {
		$temp = [array](Import-csv -Path $csv -Delimiter ";")
		$ListImport += $temp
		$AttachedFiles += $csv	
	}
	if ($ListImport) {
		$ReportSnapShotHtml += CreateHtmlArray -ArrayList $ListImport -Title "Snapshots older than 1 weeks:" -Ticket "Create INC ticket '[EDC-Virtualization] - VmWare report on week-long snapshots' with Priority=4, Category=Service Delivery, Assignment Group=EDC-Virtualization-L2"
		$blMailToTeam = $true
	}
}

if (Test-Path $ReportAutomationLevel) {
	Add-Content "$([System.dateTime]::Now) - INFO - Reporting for VM SDRS automation level" -path $LogFileName
	$ListImport = @()
	$Reports = Get-ChildItem $ReportAutomationLevel
	foreach ($csv in $Reports ) {
		$temp = [array](Import-csv -Path $csv -Delimiter ";")
		$ListImport += $temp
		$AttachedFiles += $csv	
	}
	if ($ListImport) {
		$ReportAutomationLevelHtml += CreateHtmlArray -ArrayList $ListImport -Title "SDRS Automation level:" -Ticket "Create INC ticket '[EDC-Virtualization] - SDRS Automation level' with Priority=4, Category=Service Delivery, Assignment Group=EDC-Virtualization-L2"
		$blMailToTeam = $true
	}
}

if (Test-Path $DSSettingReport) {
	Add-Content "$([System.dateTime]::Now) - INFO - Reporting check dataStore setting" -path $LogFileName
	$ListImport = @()
	$Reports = Get-ChildItem $DSSettingReport
	foreach ($csv in $Reports ) {
		$temp = [array](Import-csv -Path $csv -Delimiter ";")
		$ListImport += $temp
		$AttachedFiles += $csv	
	}
	if ($ListImport) {
		$DSSettingReportHtml += CreateHtmlArray -ArrayList $ListImport -Title "Datastore setting errors:" -Ticket "Create INC ticket '[EDC-Virtualization] - VmWare Datastore setting errors' with Priority=2, Category=Service Delivery, Assignment Group=EDC-Virtualization-L2"
		$blMailToTeam = $true
	}
}

if (Test-Path $DSOrphanedVmdkReport) {
	Add-Content "$([System.dateTime]::Now) - INFO - Reporting Orphaned Vmdk" -path $LogFileName
	$ListImport = @()
	$Reports = Get-ChildItem $DSOrphanedVmdkReport
	foreach ($csv in $Reports ) {
		$temp = [array](Import-csv -Path $csv -Delimiter ";")
		$ListImport += $temp
		$AttachedFiles += $csv	
	}
	if ($ListImport) {
		$OrphanedVmdkReportHtml += CreateHtmlArray -ArrayList $ListImport -Title "Orphaned Vmdk:" -Ticket "Create INC ticket '[EDC-Virtualization] - Orphaned Vmdk' with Priority=3, Category=Service Delivery, Assignment Group=EDC-Virtualization-L2"
		$blMailToTeam = $true
	}	
}

if (Test-Path $ApplyProfilReport) {
	Add-Content "$([System.dateTime]::Now) - INFO - Reporting ESXi profile compliance" -path $LogFileName
	$ListImport = @()
	$Reports = Get-ChildItem $ApplyProfilReport
	foreach ($csv in $Reports ) {
		$temp = [array](Import-csv -Path $csv -Delimiter ";")
		$ListImport += $temp
		$AttachedFiles += $csv	
	}
	if ($ListImport) {
		$ApplyProfilReportHtml += CreateHtmlArray -ArrayList $ListImport -Title "ESXi host profile not compliant:" -Ticket "Create INC ticket '[EDC-Virtualization] - ESXi host profile not compliant' with Priority=3, Category=Service Delivery, Assignment Group=EDC-Virtualization-L2"
		$blMailToTeam = $true
	}
}

if (Test-Path $CheckTimeReport) {
	Add-Content "$([System.dateTime]::Now) - INFO - Reporting ESXi time offset" -path $LogFileName
	$ListImport = @()
	$Reports = Get-ChildItem $CheckTimeReport
	foreach ($csv in $Reports ) {
		$temp = [array](Import-csv -Path $csv -Delimiter ";")
		$ListImport += $temp
		$AttachedFiles += $csv	
	}
	if ($ListImport) {
		$CheckTimeReportHtml += CreateHtmlArray -ArrayList $ListImport -Title "ESXi host with date time offset:" -Ticket "Create INC ticket '[EDC-Virtualization] - ESXi host with date time offset' with Priority=3, Category=Service Delivery, Assignment Group=EDC-Virtualization-L2"
		$blMailToTeam = $true
	}
}

if ($global:ScriptErrorArray.count -gt 0) {
	if ($Debug) { Write-Host $global:ScriptErrorArray }
	else {
		$MsgError = [string]($global:ScriptErrorArray | Select Script, ShortName, Severity, Description | ConvertTo-HTML -Fragment)
		Send-ReportByMail -To $EmailVmwareDailyScriptError -CopyCC $EmailVmwareDailyScriptCCError -Subject $SubjectError -htmlBody "$($MailStartError)$($MsgError)" -FilesAttachment $LogFileName
	}
}
elseif ($blMailToTeam -and ($ExecutionDay -eq $DailyCheck1)) {
	Add-Content "$([System.dateTime]::Now) - INFO - generate mail" -path $LogFileName
	$HTML = $HtmlHeader 
	if ($ReportSnapShotHtml -or $ReportErrorSnapShotHtml -or $ReportAutomationLevelHtml) { $HTML += $VMSection }
	$HTML += $ReportErrorSnapShotHtml + $ReportSnapShotHtml + $ReportAutomationLevelHtml
	if ($DSSettingReportHtml -or $OrphanedVmdkReportHtml -or $ApplyProfilReportHtml -or $CheckTimeReportHtml) { $HTML += $HypervisorSection }
	$HTML += $DSSettingReportHtml + $OrphanedVmdkReportHtml + $ApplyProfilReportHtml + $CheckTimeReportHtml
	Send-ReportByMail -From $EmailFrom -To $EmailVmwareDailyReporting -CopyCC $EmailVmwareDailyCCReporting -Subject $SubjectReporting -htmlBody $HTML -FilesAttachment $AttachedFiles -EmbededAttachments $TechnipFMCLogo
}
#Archiving
foreach ($FileName in $AttachedFiles) { Move-Item $FileName -destination (AddTimeStampFileName $FileName $ArchivePath) }
Add-Content "$([System.dateTime]::Now) - INFO - Check done" -path $LogFileName
Move-Item $LogFileName -destination "$ArchivePath"