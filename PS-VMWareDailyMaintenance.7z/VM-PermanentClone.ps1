﻿#VM-PermanentClone v1.00
#Clone VM from csv (on 'workingfile' directory)
#Every friday 8:00PM

#Update 2017-11-02, XPr:
#	-> Migrate to eu001vc0035

#- Command Line : C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe
#- Argument Line : -NonInteractive -WindowStyle Hidden -command "E:\PS-Scripts\PS-VMWareDailyMaintenance\VM-PermanentClone.ps1 -VMsListFile xxxxxxx"
#- Start in : E:\PS-Scripts\PS-VMWareDailyMaintenance\

#Input files :
#	-> ServerList-SymphonyFull.csv : Symphony Virtual Server full export
#	-> <param>.csv : list of vm to clone
#Output files :
#
#Archive files :
#	-> VM-PermanentClone-TIMESTAMP.log : batch log file name

param(
	[string]$WorkingFolder = $null,
    [string]$VMsListFile = "VMsPermanentClones.csv",
	[bool]$Debug = $false
)
[threading.thread]::CurrentThread.CurrentCulture = 'fr-FR'
if ($WorkingFolder -ne $null) { Set-Location -Path $WorkingFolder }

#**********************************************************************
#**************** CONSTANTS and VARIABLES  ****************************
#**********************************************************************
$ScriptVersion 				= "v1.00"
$LogFileName 				= "$(get-location)\workingfile\VM-PermanentClone-$($ScriptVersion)-$(get-date -format yyyyMMdd-hhmmss).log"
$ArchivePath 				= "$(get-location)\history\$(get-date -format yyyyMMdd)\"
$ServersListFileName		= "..\PS-AssetManagement\workingfile\ServerList-SymphonyFull.csv"
$ServersToClones			= "$(get-location)\sources\$($VMsListFile)"

$ExcludeDataStores 			= @("EDC-TemplateStore-vPlex", "EDC-Live-vMotion-vPlex","PRD-ORA3-VPXL-DRT-01") # array for excluded datastores
$MailSubject 				= "[EDC-VmwareMaintenance] VM Cloning"
$SubjectError 				= "[EDC-VmwareMaintenance][Script-Failed] VMware health check / VM-PermanentClone"
$MailStartError 			= "<b>Hi,<br> Error in script VM-PermanentClone for $($VMsListFile):</b><br/><br/>`n`n"

#*******************************************************
#**************** FUNCTIONS ****************************
#*******************************************************
. "..\PS-CommonLibrary\CommonFunction.ps1"

$EmailScriptError = "xprieur@external.technipenergies.com"

#*********************************************************
#************* MAIN **************************************
#*********************************************************
Add-Content "$([System.dateTime]::Now) - Starting VM-PermanentClone with $($VMsListFile) [Debug=$($Debug)]" -path $LogFileName
$CredvCenter = new-object -typename System.Management.Automation.PSCredential -argumentlist $RemoteServiceName, $CredPassSvcs
if (-Not (Get-PSSnapin VMware.VimAutomation.Core -WarningAction SilentlyContinue -ErrorAction SilentlyContinue) ) { Add-PSSnapin VMware.VimAutomation.Core -ErrorAction SilentlyContinue }

try {
	$SymphonyList = Import-csv -Path $ServersListFileName -Delimiter ";"
	$VmsList = Import-Csv $ServersToClones -Delimiter ";" 
}
catch {
	Add-Content "$([System.dateTime]::Now) - ERROR - Open csv failed" -path $LogFileName
	$MsgError = "$($_.Exception.Message) - Position: $($_.InvocationInfo.PositionMessage)"
	$ScriptErrorList.Add("Open cs", $MsgError)
}

foreach ($VmName in $VMsList) {
	$SymphonyServer = $SymphonyList | ?{ $_.Name -eq $VmName.SymphonyVmName}
	#vCenter connection
	if ($vCenter -ne $LinkClusterTovCenter[$SymphonyServer.SystemServiceClass]) {
		if ($vCenter) { Disconnect-VIServer $CurrentVC -Confirm:$false -ErrorAction SilentlyContinue }
		try {
			$vCenter = $LinkClusterTovCenter[$SymphonyServer.SystemServiceClass]
			Add-Content "$([System.dateTime]::Now) - INFO - vCenter connection: $($vCenter)" -path $LogFileName
			$CurrentVC = Connect-VIServer $vCenter -Credential $credvCenter
		}
		catch {
			Add-Content "$([System.dateTime]::Now) - ERROR - can't open $($vCenter)" -path $LogFileName
			$MsgError = "$($_.Exception.Message) - Position: $($_.InvocationInfo.PositionMessage)"
			$ScriptErrorList.Add("Connect-VIServer-$($vCenter)", $MsgError)
		}
	}
	#Get-VM with full name, if not found, short name ...
	if ([string]$SymphonyServer.Domain -ne "") { $SourceVM = Get-VM -Name "$($SymphonyServer.Name).$($SymphonyServer.Domain)" -ErrorAction "SilentlyContinue" }
	else { $SourceVM = Get-VM -Name "$($SymphonyServer.Name).tp.tpnet.intra" -ErrorAction "SilentlyContinue" }
	if ($SourceVM -eq $null) { $SourceVM = Get-VM -Name "$($SymphonyServer.Name)" -ErrorAction "SilentlyContinue" }
	if ($SourceVM -eq $null) { $SourceVM = Get-VM -Name "$($SymphonyServer.Name).*" -ErrorAction "SilentlyContinue" }
	if ($SourceVM -eq $null) { $SourceVM = Get-VM -Name "$($SymphonyServer.Name)*" -ErrorAction "SilentlyContinue" }
	
	if ($SourceVM) {
		$SourceVMView = Get-View $SourceVM
		$hardDisks = $SourceVMView.Config.Hardware.Device | Where-Object {$_.getType().FullName -eq "VMware.Vim.VirtualDisk"}
		$SourceVMSize = 0
		$hardDisks | %{ $SourceVMSize += ($_.CapacityInKB * 1KB / 1GB) }
		Add-Content "$([System.dateTime]::Now) - INFO - Starting clone process for $($SourceVM.Name) hosted on cluster $($SymphonyServer.SystemServiceClass) for VM Size $($SourceVMSize) Gb" -path $LogFileName
		$SplittedCloneName = $SourceVM.Name.ToLower().Split(".")
		$SplittedCloneName[0] += "-c"
		$CloneName = $SplittedCloneName -join "."
		Add-Content "$([System.dateTime]::Now) - INFO - Name for clone: $($CloneName)" -path $LogFileName
		$TargetFolder = Get-Folder -Id $SourceVM.FolderId
		$Datastores = Get-View -ViewType DataStore | Where {$_.Name.Contains("VPXL" ) -and !($ExcludeDataStores -contains $_.name) -and $SourceVM.VMHost.DatastoreIdList -contains $_.Summary.Datastore }
		$Datastores | ForEach-Object {$_ | Add-Member -MemberType NoteProperty -Name FreeSpace -Value ($_.Summary.FreeSpace/1024/1024/1024) }
		$Datastores = $Datastores | Sort-Object FreeSpace -Descending
		$Datastore = Get-Datastore $Datastores[0].Name		
		Add-Content "$([System.dateTime]::Now) - INFO - Target datastore: $($Datastore.Name), freespace $($Datastore.FreeSpaceGB) Gb" -path $LogFileName
		if ($Datastore.FreeSpaceGB -gt $SourceVMSize) {
			#Get current clone and remove it
			$CurrentClone = Get-VM $CloneName -ErrorAction SilentlyContinue
			if ($CurrentClone -ne $Null) {
				Add-Content "$([System.dateTime]::Now) - INFO - Removeing current clone: $($CloneName)" -path $LogFileName
				if (!$Debug) { Remove-VM $CurrentClone -DeleteFromDisk -Confirm:$False }
			}
			$Error.Clear()
			if (!$Debug) { New-VM -VM $SourceVM -Name $CloneName -Datastore $Datastore -Location $TargetFolder -VMHost $SourceVM.VMHost }
			if ($Error.Count -eq 0) { Add-Content "$([System.dateTime]::Now) - INFO - Clone done" -path $LogFileName }
			else {
				Add-Content "$([System.dateTime]::Now) - ERROR - Error when clonning" -path $LogFileName
				$ScriptErrorList.Add("$VmName.SymphonyVmName-Clonning", "Error when clonning")
			}
		}
		else {
			Add-Content "$([System.dateTime]::Now) - ERROR - Not enought space on $($Datastore.Name)" -path $LogFileName
			$ScriptErrorList.Add("$VmName.SymphonyVmName-NoSpace", "Not enought space on $($Datastore.Name)")
		}
	}
	else {
		Add-Content "$([System.dateTime]::Now) - ERROR - $($SymphonyServer.Name) not found" -path $LogFileName
		$ScriptErrorList.Add("$VmName.SymphonyVmName-NotFound", "Not found in vCenter $($vCenter)")
	}
}

if ($ScriptErrorList.count -gt 0) {
	$MsgError = [string]($ScriptErrorList.GetEnumerator() | ConvertTo-HTML -Fragment)
	Send-SMTPmail -to $EmailScriptError -htmlBody $MsgError -Subject $SubjectError -Start "$($MailStyle)$($MailStartError)" -FilesAttachment $LogFileName
}

Add-Content "$([System.dateTime]::Now) - INFO - Batch end" -path $LogFileName
Move-Item $LogFileName -destination "$ArchivePath" -force
Disconnect-VIServer * -Confirm:$false