#vCenter-ExportEvent
#Export item from Oracle DB table
#Subtask sent by VMwareDailyMaintenance

#- Command Line : C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe
#- Argument Line : -command "E:\PS-Scripts\PS-VMWareDailyMaintenance\vCenter-ExportEvent.ps1"
#- Start in : E:\PS-Scripts\PS-VMWareDailyMaintenance\
param(
	[string[]]$WorkingFolder = $null
)
[threading.thread]::CurrentThread.CurrentCulture = 'fr-FR'
if ($WorkingFolder -ne $null) {
	set-location -Path "$($WorkingFolder)"
}

#***********************************************************************
#**************** D�claration des variables ****************************
#***********************************************************************
$ExportFileNames = @{}
$ExportFileNames.Add("Compteur", 						"$(get-location)\workingfile\Compteurs.txt")
$ExportFileNames.Add("TaskPerTypeMonth",				"$(get-location)\workingfile\TaskPerTypeMonth.txt")
$ExportFileNames.Add("EventPerTypePerMonth",			"$(get-location)\workingfile\EventPerTypePerMonth.txt")
$ExportFileNames.Add("EventPerTypePerUserPerMonth",		"$(get-location)\workingfile\EventPerTypePerUserPerMonth.txt")

$ConvertPatterns = @{}
$ConvertPatterns.Add("Compteur", 						"(.{50})")
$ConvertPatterns.Add("TaskPerTypeMonth",				"(.{95}) (.{10}) (.{10}) (.{9})")
$ConvertPatterns.Add("EventPerTypePerMonth",			"(.{95}) (.{10}) (.{10}) (.{9})")
$ConvertPatterns.Add("EventPerTypePerUserPerMonth",		"(.{95}) (.{95}) (.{10}) (.{10}) (.{9})")

$ConvertFiedls = @{}
$ConvertFiedls.Add("Compteur", 							'$1')
$ConvertFiedls.Add("TaskPerTypeMonth",					'$1,$2,$3,$4')
$ConvertFiedls.Add("EventPerTypePerMonth",				'$1,$2,$3,$4')
$ConvertFiedls.Add("EventPerTypePerUserPerMonth",		'$1,$2,$3,$4,$5')

$XlsExport = "$(get-location)\workingfile\EventReport.xlsx"
$LogFileName = "$(get-location)\workingfile\vCenter-ExportEvent-$(get-date -format HH-mm-ss).log"
$ArchivePath = "$(get-location)\history\$(get-date -format yyyyMMdd)\"

$SubjectError = "-- Export vCenter Events  --"
$MailStartError = "<b>Hi,<br> Error in script vCenter-ExportEvent<br/><br/>`n`n"

#*******************************************************
#**************** FUNCTIONS ****************************
#*******************************************************
. "..\PS-CommonLibrary\CommonFunction.ps1"
. "..\PS-CommonLibrary\Export-XLSX.ps1"

#*********************************************************
#************* MAIN **************************************
#*********************************************************
Add-Content "$([System.dateTime]::Now) - INFO - Starting vCenter-ExportEvent on Primary vCenter" -path $LogFileName
$RemoteCreds = New-Object System.Management.Automation.PSCredential ($RemoteServiceName, $CredPassSvcs)

if ((Test-Path -path $ArchivePath) -ne $true) {
	New-Item $ArchivePath -type Directory | out-null
}

#Connect to Oracle DB and remove some event (backup)
try {
	$CommandLine = 'vcenter55/vCenter55$0914@vCenterDB.WORLD @"includ\vCenter-RemoveSomeEvent"'
	Add-Content "$([System.dateTime]::Now) - INFO - Starting vCenter-RemoveSomeEvent.sql" -path $LogFileName
	$p = Start-Process -FilePath "sqlplus.exe" -ArgumentList "$($CommandLine)" -Wait -PassThru
	
	if (($p.ExitCode -eq 0) -and ($p.HasExited)) {
		Add-Content "$([System.dateTime]::Now) - INFO - Remove SQL Command completed with success" -path $LogFileName
	}
	else {
		Add-Content "$([System.dateTime]::Now) - ERROR - Remove SQL Command failed" -path $LogFileName
		$ScriptErrorList.Add("RemoveSomeEvent.cmd", $p.ExitCode)
	}
}
catch {
	Add-Content "$([System.dateTime]::Now) - ERROR - Remove SQL Command on Start-Process" -path $LogFileName
	$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
	Add-Content $MsgError -path $LogFileName
	$ScriptErrorList.Add("RemoveSomeEvent.cmd Start-Process", $MsgError)
}

$blFound = $false
#Connect to Oracle DB and return all lock
try {
	$CommandLine = 'vcenter55/vCenter55$0914@vCenterDB.WORLD @"includ\vCenter-ExportEvent"'
	Add-Content "$([System.dateTime]::Now) - INFO - Starting vCenter-ExportEvent.sql" -path $LogFileName
	$p = Start-Process -FilePath "sqlplus.exe" -ArgumentList "$($CommandLine)" -Wait -PassThru
	
	if (($p.ExitCode -eq 0) -and ($p.HasExited)) {
		Add-Content "$([System.dateTime]::Now) - INFO - Read SQL Command completed with success" -path $LogFileName
		$blFound = $true
	}
	else {
		Add-Content "$([System.dateTime]::Now) - ERROR - Read SQL Command failed" -path $LogFileName
		$ScriptErrorList.Add("ExportEvent.cmd", $p.ExitCode)
	}
}
catch {
	Add-Content "$([System.dateTime]::Now) - ERROR - Read SQL Command on Start-Process" -path $LogFileName
	$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
	Add-Content $MsgError -path $LogFileName
	$ScriptErrorList.Add("ExportEvent.cmd Start-Process", $MsgError)
	
}

#Analyse file
try {
	if ($blFound) {
		$blFirst = $true
		foreach ($SourceFile in $ExportFileNames.GetEnumerator()) {
			$CsvFileName = $SourceFile.Value -replace ".txt",".csv"
			$CsvFormat  = ((gc $SourceFile.Value | where { ($_ -ne "") -and -not($_ -match "-----") }) -replace $ConvertPatterns[$SourceFile.Name], $ConvertFiedls[$SourceFile.Name]) -replace '\s+', ' ' > $CsvFileName
			$CsvFormat = Import-csv -Path $CsvFileName | where {$_ -ne ""} 
			if ($blFirst) {
				$CsvFormat | ExportXLSX "$($XlsExport)" -WorkSheetName $SourceFile.Name
				$blFirst = $false
			}
			else {
				$CsvFormat | ExportXLSX "$($XlsExport)" -WorkSheetName $SourceFile.Name -Append
			}
			Remove-Item $SourceFile.Value
			Move-Item $CsvFileName -destination (AddTimeStampFileName $CsvFileName $ArchivePath)
		}
	}
	Move-Item $XlsExport -destination (AddTimeStampFileName $XlsExport $ArchivePath)
}
catch {
	Add-Content "$([System.dateTime]::Now) - ERROR - Analyse file" -path $LogFileName
	$MsgError = "Line number : $($_.InvocationInfo.ScriptLineNumber)<br>Position : $($_.InvocationInfo.PositionMessage)<br>$($_.Exception)"
	Add-Content $MsgError -path $LogFileName
	$ScriptErrorList.Add("Analyse file", $MsgError)
}

if ($ScriptErrorList.count -gt 0) {
	$MsgError = [string]($ScriptErrorList.GetEnumerator() | ConvertTo-HTML -Fragment)
	send-SMTPmail -to $EmailScriptError -htmlBody $MsgError -Subject $SubjectError -Start "$($MailStyle)$($MailStartError)"
}

Add-Content "$([System.dateTime]::Now) - INFO - Batch done" -path $LogFileName
Move-Item $LogFileName -destination "$ArchivePath"
