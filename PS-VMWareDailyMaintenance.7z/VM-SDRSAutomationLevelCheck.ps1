#VM-SDRSAutomationLevelCheck v1.0
#Report if SDRS automation level setting on VM is set to disable
#Subtask sent by VMwareDailyMaintenance.ps1

param(
	[string]$WorkingFolder = $null,
	[string]$JobName = $null,
    [string]$vCenter = "eu001vc0011.tp.tpnet.intra",
	[bool]$Debug = $false
)
[threading.thread]::CurrentThread.CurrentCulture = 'fr-FR'
if ($WorkingFolder -ne $null) { Set-Location -Path $WorkingFolder }

#**********************************************************************
#**************** CONSTANTS and VARIABLES  ****************************
#**********************************************************************
$ScriptVersion 				= "v1.0"
$LogFileName 				= "$(get-location)\workingfile\VM-SDRSAutomationLevelCheck-$($vCenter)-$($ScriptVersion)-$(get-date -format yyyyMMdd-hhmmss).log"
$ArchivePath 				= "$(get-location)\history\$(get-date -format yyyyMMdd)\"
$ReportAutomationLevelCsv	= "$(get-location)\workingfile\VM-SDRSAutomationLevelCheck-Report-$($vCenter)-$($ScriptVersion).csv"

#*******************************************************
#**************** FUNCTIONS ****************************
#*******************************************************
. "..\PS-CommonLibrary\CommonFunction.ps1"

#*********************************************************
#************* MAIN **************************************
#*********************************************************
Add-Content "$([System.dateTime]::Now) - Starting VM-SDRSAutomationLevelCheck for $($vCenter) [Debug=$($Debug)]" -path $LogFileName
$CredvCenter = new-object -typename System.Management.Automation.PSCredential -argumentlist $RemoteServiceName, $CredPassSvcs
if ((Test-Path -path $ArchivePath) -ne $True) { New-Item $ArchivePath -type Directory }

#Chargement du PowerCli si nécessaire
if (!(Get-Module -name VMware.VimAutomation.Core)) { Get-Module -ListAvailable VMware.VimAutomation.Core | Import-Module } 
try {
	Add-Content "$([System.dateTime]::Now) - INFO - Connect to vCenter: $($vCenter)" -path $LogFileName
	Connect-VIServer $vCenter -Credential $credvCenter | out-null
}
catch {	AddTrackError -ShortName "Connect to vCenter:" -Severity 0 -ErrRecord $_ }

try {
	[array]$ReportAutomationLevel = Get-DatastoreCluster | %{ $_.ExtensionData.PodStorageDrsEntry.StorageDrsConfig.VmConfig } | ? { $_.Enabled -eq $False } | %{ Get-View $_.VM | Select Name }
	if ($ReportAutomationLevel.Count -gt 0) { $ReportAutomationLevel | Select @{Name="vCenter";Expression={$vCenter}}, Name | Export-Csv -path $ReportAutomationLevelCsv -Delimiter ";" -Force -NoTypeInformation }
}
catch {	AddTrackError -ShortName "Get-DatastoreCluster:" -Severity 0 -ErrRecord $_ }

Add-Content "$([System.dateTime]::Now) - INFO - Batch end" -path $LogFileName
Move-Item $LogFileName -destination "$ArchivePath" -force
return $global:ScriptErrorArray
Disconnect-VIServer -Confirm:$False
