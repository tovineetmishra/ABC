﻿#ESXi-CheckTime
#
#Subtask sent by VMwareDailyMaintenance

#- Command Line : C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe
#- Argument Line : -command "E:\PS-Scripts\PS-VMWareDailyMaintenance\ESXi-CheckTime.ps1"
#- Start in : E:\PS-Scripts\PS-VMWareDailyMaintenance\
param(
	[string[]]$WorkingFolder = $null,
	[string[]]$vCenter = "eu001vc0011.tp.tpnet.intra"
)
[threading.thread]::CurrentThread.CurrentCulture = 'fr-FR'
if ($WorkingFolder -ne $null) {
	set-location -Path "$($WorkingFolder)"
}

#**********************************************************************
#**************** CONSTANTS and VARIABLES  ****************************
#**********************************************************************
$LogFileName 						= "$(get-location)\workingfile\ESXi-CheckTime-$($vCenter)-$(get-date -format yyyyMMdd-hhmmss).log"
$ExportListCsv 						= "$(get-location)\workingfile\ESXi-CheckTime-$($vCenter).csv"
$ArchivePath						= "$(get-location)\history\$(get-date -format yyyyMMdd)\"

$allowedDifferenceSeconds = "0.2" 
$allowedDifferenceSecondsneg = "-0.2" 
$startTime = Get-Date

$exportList = @()


#*******************************************************
#**************** FUNCTIONS ****************************
#*******************************************************
. "..\PS-CommonLibrary\CommonFunction.ps1"


$EmailVmwareDailyCCReporting 		= "xprieur@external.technipenergies.com" #"edc-system-l3@technip.com,scts-edcoperation@technip.onmicrosoft.com"
$EmailScriptError 					= "xprieur@external.technipenergies.com" #"edc-system-l3@technip.com"

$ReportingEmailStart 				= "<b>Hi,<br>The list of the following ESXi have an datatime offset.</b></br>`n`n"
$ReportingSubject					= "[EDC-VmwareCheck] NTP check on ESXi for $($vCenter)"
$ScriptErrorMailStart				= "<b>Hi,<br> NTP check on ESX :</b><br/><br/>`n`n"
$ScriptErrorSubject 				= "[EDC-VmwareCheck][EDC-Script-Failed] NTP check on ESXi for $($vCenter)"

#*********************************************************
#************* MAIN **************************************
#*********************************************************
Add-Content "$([System.dateTime]::Now) - Starting ESXi-CheckTime for $($vCenter)" -path $LogFileName

If (-Not (Get-PSSnapin VMware.VimAutomation.Core -WarningAction SilentlyContinue -ErrorAction SilentlyContinue) ) {
	Add-Content "$([System.dateTime]::Now) - INFO - Chargement PowerCLI" -path $LogFileName
	Add-PSSnapin VMware.VimAutomation.Core -ErrorAction SilentlyContinue
}

try {
	$CredvCenter = New-Object System.Management.Automation.PSCredential ($RemoteServiceName, $CredPassSvcs)
}
catch {
	Add-Content "$([System.dateTime]::Now) - ERROR - PSCredential" -path $LogFileName
	$MsgError = "$($_.Exception.Message) - Position : $($_.InvocationInfo.PositionMessage)"
	Add-Content $MsgError -path $LogFileName
	$ScriptErrorList.Add("PSCredential", $MsgError)
}
#Open vCenter Connection
try {
	Add-Content "$([System.dateTime]::Now) - INFO - Connect to vCenter : $($vCenter)" -path $LogFileName
	Connect-VIServer $vCenter -Credential $credvCenter
}
catch {
	Add-Content "$([System.dateTime]::Now) - ERROR - Can't connect to vcenter $($vCenter)" -path $LogFileName
	$MsgError = "Line number : $($_.InvocationInfo.ScriptLineNumber)<br>Position : $($_.InvocationInfo.PositionMessage)<br>$($_.Exception)"
	Add-Content $MsgError -path $LogFileName
	$ScriptErrorList.Add("vCenter", $MsgError)
}
try {
	Add-Content "$([System.dateTime]::Now) - INFO - Get-View" -path $LogFileName
	$EsxiViews = Get-View -ViewType HostSystem -Property Name, ConfigManager.DateTimeSystem
}
catch {
	Add-Content "$([System.dateTime]::Now) - ERROR - Get-View" -path $LogFileName
	$MsgError = "Line number : $($_.InvocationInfo.ScriptLineNumber)<br>Position : $($_.InvocationInfo.PositionMessage)<br>$($_.Exception)"
	Add-Content $MsgError -path $LogFileName
	$ScriptErrorList.Add("Get-View", $MsgError)
}

foreach ($Esxi in $EsxiViews) {  
	try {
		Add-Content "$([System.dateTime]::Now) - INFO - Checking $($Esxi.Name)" -path $LogFileName
		#get host datetime system  
		$dts = get-view $Esxi.ConfigManager.DateTimeSystem  
		  
		#get host time  
		$t = $dts.QueryDateTime()  
		$utc =  [DateTime]::UtcNow
		#calculate time difference in seconds  
		$s = ($t - [DateTime]::UtcNow).TotalSeconds  
		  
		#check if time difference is too much  
		if (( $s -gt $allowedDifferenceSeconds)-or ($s -lt $allowedDifferenceSecondsneg)) { 
			$EsxiHost = Get-VMHost -Name $ESXi.Name
			$NetSetting = $EsxiHost | VMHostNtpServer
			$NtpService = $EsxiHost | Get-VMHostService | where {$_.Key -eq "ntpd"}
			#print host and time difference in seconds  
			$row = "" | select HostName,UTC, ESXDateTime, Seconds, Ntp1, Ntp2, NtpPolicy, TnpRunning
			$row.HostName = $Esxi.Name 
			$row.UTC = $utc
			$row.ESXDateTime = $t		
			$row.Seconds = $s
			$row.NtpPolicy = $NtpService.Policy
			$row.TnpRunning = $NtpService.Running
			if ($NetSetting -gt 0) { $row.Ntp1 = $NetSetting[0] }
			if ($NetSetting -gt 1) { $row.Ntp2 = $NetSetting[1] }
			$exportList += $row 
		}  
	}
	catch {
		Add-Content "$([System.dateTime]::Now) - ERROR - on $($Esxi.Name)" -path $LogFileName
		$MsgError = "Line number : $($_.InvocationInfo.ScriptLineNumber)<br>Position : $($_.InvocationInfo.PositionMessage)<br>$($_.Exception)"
		Add-Content $MsgError -path $LogFileName
		$ScriptErrorList.Add("CheckingError-$($Esxi.Name)", $MsgError)
	}
} 
Add-Content "$([System.dateTime]::Now) - INFO - $($EsxiViews.count) ESXi check, $($exportList.Count) with more than $($allowedDifferenceSeconds) second differntial." -path $LogFileName

if ($exportList.count -gt 0) {
	Add-Content "$([System.dateTime]::Now) - INFO - Exporting csv file." -path $LogFileName
	$exportList | Export-Csv -path $ExportListCsv -Delimiter ";" -Force -NoTypeInformation
}

if ($ScriptErrorList.count -gt 0) {
	$MsgError = [string]($ScriptErrorList.GetEnumerator() | ConvertTo-HTML -Fragment)
	send-SMTPmail -to $EmailScriptError -htmlBody $MsgError -Subject $ScriptErrorSubject -Start "$($MailStyle)$($ScriptErrorMailStart)" -FilesAttachment $LogFileName
}
Add-Content "$([System.dateTime]::Now) - INFO - Export done" -path $LogFileName
Move-Item $LogFileName -destination "$ArchivePath" -force
Disconnect-VIServer -Confirm:$false
